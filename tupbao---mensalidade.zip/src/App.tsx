/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Settings, 
  HelpCircle, 
  Flame, 
  Heart, 
  FolderDown, 
  RotateCcw, 
  Briefcase, 
  UserCheck, 
  CheckCircle,
  FileSpreadsheet
} from 'lucide-react';
import { DashboardStats } from './components/DashboardStats';
import { MediumList } from './components/MediumList';
import { FeesList } from './components/FeesList';
import { MediumForm } from './components/MediumForm';
import { MediumView } from './components/MediumView';
import { LoginScreen } from './components/LoginScreen';
import { Medium, MonthlyFee, FeeStatus, TerreiroEvent, BillPayable } from './types';
import { 
  loadMediumsFromStorage, 
  saveMediumsToStorage, 
  loadFeesFromStorage, 
  saveFeesToStorage,
  loadEventsFromStorage,
  saveEventsToStorage,
  loadBillsFromStorage,
  saveBillsToStorage
} from './data';
import { EventsManagement } from './components/EventsManagement';
import { BillsPayableManagement } from './components/BillsPayableManagement';
import { TupbaoLogo } from './components/TupbaoLogo';
import { sendEmailNotification } from './services/notificationService';

export default function App() {
  // DB State
  const [mediums, setMediums] = useState<Medium[]>([]);
  const [fees, setFees] = useState<MonthlyFee[]>([]);
  const [events, setEvents] = useState<TerreiroEvent[]>([]);
  const [bills, setBills] = useState<BillPayable[]>([]);
  
  // Auth State
  const [isUserLoggedIn, setIsUserLoggedIn] = useState<boolean>(false);
  const [userSessionRole, setUserSessionRole] = useState<'admin' | 'medium' | null>(null);
  const [sessionMediumId, setSessionMediumId] = useState<string | null>(null);
  
  // UI State
  const [currentMode, setCurrentMode] = useState<'admin' | 'medium'>('admin');
  const [activeAdminTab, setActiveAdminTab] = useState<string>('overview');
  
  // Modals state
  const [showAddMediumModal, setShowAddMediumModal] = useState(false);
  const [editingMedium, setEditingMedium] = useState<Medium | null>(null);

  // Load from local storage on mount
  useEffect(() => {
    setMediums(loadMediumsFromStorage());
    setFees(loadFeesFromStorage());
    setEvents(loadEventsFromStorage());
    setBills(loadBillsFromStorage());
  }, []);

  // Save to storage helpers
  const updateMediums = (newMediums: Medium[]) => {
    setMediums(newMediums);
    saveMediumsToStorage(newMediums);
  };

  const updateFees = (newFees: MonthlyFee[]) => {
    setFees(newFees);
    saveFeesToStorage(newFees);
  };

  const updateEvents = (newEvents: TerreiroEvent[]) => {
    setEvents(newEvents);
    saveEventsToStorage(newEvents);
  };

  const updateBills = (newBills: BillPayable[]) => {
    setBills(newBills);
    saveBillsToStorage(newBills);
  };

  // Add/Edit Medium handler
  const handleSaveMedium = (data: Omit<Medium, 'id'> & { id?: string }) => {
    if (data.id) {
      // Editing
      const idx = mediums.findIndex(m => m.id === data.id);
      if (idx !== -1) {
        const updated = [...mediums];
        updated[idx] = { ...mediums[idx], ...data } as Medium;
        
        // Also update mediumName on associated fees to maintain database consistency
        const updatedFees = fees.map(fee => {
          if (fee.mediumId === data.id) {
            return { ...fee, mediumName: data.name };
          }
          return fee;
        });

        updateMediums(updated);
        updateFees(updatedFees);
      }
    } else {
      // Creating
      const newId = `m${Date.now()}`;
      const newMedium: Medium = {
        id: newId,
        ...data
      } as Medium;
      updateMediums([...mediums, newMedium]);
    }
    
    setShowAddMediumModal(false);
    setEditingMedium(null);
  };

  const handleDeleteMedium = (id: string) => {
    const updated = mediums.filter(m => m.id !== id);
    updateMediums(updated);
  };

  const handleIssueFee = async (mediumId: string, referenceMonth: string, value: number, dueDate: string) => {
    const targetMedium = mediums.find(m => m.id === mediumId);
    if (!targetMedium) return;

    // Check if copy already exists
    const duplicate = fees.find(f => f.mediumId === mediumId && f.referenceMonth === referenceMonth);
    if (duplicate) {
      alert(`O médium ${targetMedium.name} já possui uma mensalidade emitida para o mês ${referenceMonth}.`);
      return;
    }

    const newFee: MonthlyFee = {
      id: `fee_${Date.now()}_${mediumId}`,
      mediumId,
      mediumName: targetMedium.name,
      referenceMonth,
      dueDate,
      value,
      status: 'pending',
      paymentDate: null,
      paymentMethod: null
    };

    updateFees([...fees, newFee]);
    
    // Simulate sending email
    await sendEmailNotification({
      medium: targetMedium,
      fee: newFee,
      type: 'issued'
    });

    alert(`Mensalidade de ${referenceMonth} emitida com sucesso para ${targetMedium.name}!`);
  };

  // Bulk generate fees for active mediums
  const handleBulkGenerateFees = async (referenceMonth: string) => {
    const activeMediums = mediums.filter(m => m.active);
    if (activeMediums.length === 0) {
      alert("Não há médiuns ativos cadastrados no momento para receber mensalidades.");
      return;
    }

    let createdCount = 0;
    const newFeesList = [...fees];
    const generatedFees: { medium: Medium, fee: MonthlyFee }[] = [];

    activeMediums.forEach(medium => {
      // Avoid duplication
      const exists = fees.some(f => f.mediumId === medium.id && f.referenceMonth === referenceMonth);
      if (!exists) {
        const newFee: MonthlyFee = {
          id: `fee_bulk_${Date.now()}_${medium.id}_${referenceMonth}`,
          mediumId: medium.id,
          mediumName: medium.name,
          referenceMonth,
          dueDate: `${referenceMonth}-10`, // Default due date is the 10th
          value: medium.monthlyValue,
          status: 'pending',
          paymentDate: null,
          paymentMethod: null
        };
        newFeesList.push(newFee);
        generatedFees.push({ medium, fee: newFee });
        createdCount++;
      }
    });

    if (createdCount > 0) {
      updateFees(newFeesList);
      
      // Send notifications for generated fees
      for (const { medium, fee } of generatedFees) {
        await sendEmailNotification({ medium, fee, type: 'issued' });
      }

      alert(`Mensalidades em lote geradas com sucesso para ${createdCount} médiuns ativos!`);
    } else {
      alert(`Todas mensalidades de ${referenceMonth} já haviam sido geradas anteriormente.`);
    }
  };

  // Update payment status (paid, pending, overdue)
  const handleUpdateFeeStatus = async (feeId: string, status: FeeStatus, paymentMethod: any = null) => {
    let targetFeeToNotify: MonthlyFee | null = null;
    let targetMediumToNotify: Medium | null = null;

    const updated = fees.map(fee => {
      if (fee.id === feeId) {
        const newFee = {
          ...fee,
          status,
          paymentDate: status === 'paid' ? new Date().toISOString().split('T')[0] : null,
          paymentMethod: status === 'paid' ? (paymentMethod || 'pix') : null,
          comprovanteUploaded: status === 'paid' ? false : fee.comprovanteUploaded // Clear proof status on confirmation
        };

        if (status === 'paid' && fee.status !== 'paid') {
          targetFeeToNotify = newFee;
          targetMediumToNotify = mediums.find(m => m.id === fee.mediumId) || null;
        }
        
        return newFee;
      }
      return fee;
    });
    updateFees(updated);

    if (targetFeeToNotify && targetMediumToNotify) {
      await sendEmailNotification({
        medium: targetMediumToNotify,
        fee: targetFeeToNotify,
        type: 'payment_confirmed'
      });
    }
  };

  const handleDeleteFee = (feeId: string) => {
    const updated = fees.filter(f => f.id !== feeId);
    updateFees(updated);
  };

  // Simulation: Medium submits comprovante
  const handleUploadComprovante = (feeId: string, fileName: string) => {
    const updated = fees.map(f => {
      if (f.id === feeId) {
        return {
          ...f,
          comprovanteUploaded: true,
          comprovanteFileName: fileName
        };
      }
      return f;
    });
    updateFees(updated);
    alert(`Comprovante de pagamento ("${fileName}") enviado eletronicamente para a administração com sucesso! Sua mensalidade mudou para aguardando liberação.`);
  };

  // Simulation: Instant PIX payment
  const handleSimulateInstantPay = async (feeId: string) => {
    const targetFee = fees.find(f => f.id === feeId);
    if (!targetFee) return;
    
    let targetFeeToNotify: MonthlyFee | null = null;
    let targetMediumToNotify: Medium | null = null;

    const updated = fees.map(f => {
      if (f.id === feeId) {
        const newFee = {
          ...f,
          status: 'paid' as FeeStatus,
          paymentDate: new Date().toISOString().split('T')[0],
          paymentMethod: 'pix' as const
        };
        targetFeeToNotify = newFee;
        targetMediumToNotify = mediums.find(m => m.id === f.mediumId) || null;
        return newFee;
      }
      return f;
    });
    updateFees(updated);
    
    if (targetFeeToNotify && targetMediumToNotify) {
      await sendEmailNotification({
        medium: targetMediumToNotify,
        fee: targetFeeToNotify,
        type: 'payment_confirmed'
      });
    }

    alert(`Simulação de pagamento realizada! O Templo recebeu R$ ${targetFee.value.toFixed(2)} instantaneamente via PIX e emitiu baixa automática.`);
  };

  // Database Backup Actions
  const handleExportBackup = () => {
    const dataStr = JSON.stringify({ mediums, fees, events, bills }, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `backup_terreiro_financeiro_${new Date().toISOString().slice(0,10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleResetData = () => {
    if (confirm("Gostaria de limpar as alterações e resetar os dados fictícios padrão para demonstração?")) {
      localStorage.removeItem('terreiro_mediums');
      localStorage.removeItem('terreiro_fees');
      localStorage.removeItem('terreiro_events');
      localStorage.removeItem('terreiro_bills');
      window.location.reload();
    }
  };

  const handleCreateBill = (billData: Omit<BillPayable, 'id'>) => {
    const newBill: BillPayable = {
      id: `bill_${Date.now()}`,
      ...billData
    };
    updateBills([...bills, newBill]);
  };

  const handleUpdateBill = (updatedBill: BillPayable) => {
    const updated = bills.map(b => b.id === updatedBill.id ? updatedBill : b);
    updateBills(updated);
  };

  const handleDeleteBill = (id: string) => {
    const updated = bills.filter(b => b.id !== id);
    updateBills(updated);
  };

  const handleCreateEvent = (eventData: Omit<TerreiroEvent, 'id' | 'billingIssued'>) => {
    const newEvent: TerreiroEvent = {
      id: `event_${Date.now()}`,
      ...eventData,
      billingIssued: false
    };
    updateEvents([...events, newEvent]);
  };

  const handleDeleteEvent = (id: string) => {
    const updated = events.filter(e => e.id !== id);
    updateEvents(updated);
  };

  const handleLaunchEventFees = async (eventId: string) => {
    const event = events.find(e => e.id === eventId);
    if (!event) return;

    const activeMediums = mediums.filter(m => m.active);
    if (activeMediums.length === 0) {
      alert("Não há médiuns ativos cadastrados para ratear a taxa do evento.");
      return;
    }

    const referenceMonth = event.date.slice(0, 7); // Format "YYYY-MM"
    const newFeesList = [...fees];
    const generatedFees: { medium: Medium, fee: MonthlyFee }[] = [];

    activeMediums.forEach(medium => {
      const newFee: MonthlyFee = {
        id: `fee_event_${Date.now()}_${medium.id}_${event.id}`,
        mediumId: medium.id,
        mediumName: medium.name,
        referenceMonth: referenceMonth,
        dueDate: event.date,
        value: event.costPerMedium,
        status: 'pending',
        paymentDate: null,
        paymentMethod: null,
        isEventFee: true,
        eventName: event.name
      };
      newFeesList.push(newFee);
      generatedFees.push({ medium, fee: newFee });
    });

    updateFees(newFeesList);

    // Mark event's billingIssued = true
    const updatedEvents = events.map(e => e.id === eventId ? { ...e, billingIssued: true } : e);
    updateEvents(updatedEvents);

    // Send notifications for generated event fees
    for (const { medium, fee } of generatedFees) {
      await sendEmailNotification({ medium, fee, type: 'issued' });
    }
  };

  const handleRegisterPassword = (mediumId: string, password: string) => {
    const updated = mediums.map(m => {
      if (m.id === mediumId) {
        return { ...m, password };
      }
      return m;
    });
    updateMediums(updated);
  };

  const getNextSuggestedReg = () => {
    const numbers = mediums
      .map(m => parseInt(m.registrationNumber || '0', 10))
      .filter(num => !isNaN(num) && num > 0);
    const maxNum = numbers.length > 0 ? Math.max(...numbers) : 1000;
    return String(maxNum + 1);
  };

  if (!isUserLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
        <LoginScreen
          mediums={mediums}
          onLoginAdmin={() => {
            setIsUserLoggedIn(true);
            setUserSessionRole('admin');
            setCurrentMode('admin');
          }}
          onLoginMedium={(mediumId) => {
            setIsUserLoggedIn(true);
            setUserSessionRole('medium');
            setSessionMediumId(mediumId);
            setCurrentMode('medium');
          }}
          onRegisterPassword={handleRegisterPassword}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      
      {/* Sacred aesthetic Top Bar Banner */}
      <header className="bg-slate-950 text-white relative border-b-2 border-amber-500 shadow-sm">
        {/* subtle vector light mask */}
        <div className="absolute inset-0 bg-radial from-slate-900 to-slate-950 opacity-90 -z-10" />
        
        <div className="max-w-7xl mx-auto px-4 py-5 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-md border-2 border-amber-500/20">
              <TupbaoLogo className="w-11 h-11" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-extrabold tracking-tight text-amber-400">TUPBAO</h1>
                <span className="text-[10px] bg-amber-500/10 text-amber-300 font-bold px-2 py-0.5 rounded-sm uppercase tracking-wider border border-amber-500/20">Mensalidade</span>
              </div>
              <p className="text-xs text-slate-300">Gestão das Obrigações e contribuições mensais</p>
            </div>
          </div>

          {/* Quick toggle mode selector & Session actions */}
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
            {userSessionRole === 'admin' && (
              <div className="flex bg-slate-900 rounded-xl p-1 border border-slate-800 shadow-inner w-full">
                <button
                  onClick={() => setCurrentMode('admin')}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                    currentMode === 'admin' 
                      ? 'bg-amber-600 text-white shadow-md' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Briefcase className="h-4.5 w-4.5" />
                  Painel Gestão
                </button>
                <button
                  onClick={() => setCurrentMode('medium')}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                    currentMode === 'medium' 
                      ? 'bg-amber-600 text-white shadow-md' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <UserCheck className="h-4.5 w-4.5" />
                  Portal do Médium
                </button>
              </div>
            )}
            
            <button
              onClick={() => {
                setIsUserLoggedIn(false);
                setUserSessionRole(null);
                setSessionMediumId(null);
              }}
              className="bg-slate-900 hover:bg-slate-850 hover:text-amber-400 text-slate-300 border border-slate-800 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer w-full sm:w-auto"
            >
              Sair
            </button>
          </div>
        </div>
      </header>

      {/* Main app box */}
      <main className="max-w-7xl mx-auto px-4 py-8 flex-1 w-full space-y-6">
        
        {currentMode === 'admin' ? (
          <div className="space-y-6">
            
            {/* Admin navigation tabs */}
            <div className="flex border-b border-amber-200/55 text-sm gap-2">
              <button
                onClick={() => setActiveAdminTab('overview')}
                className={`py-3 px-4 font-bold border-b-2 transition-all cursor-pointer ${
                  activeAdminTab === 'overview' 
                    ? 'border-amber-600 text-amber-800 bg-amber-50/40 rounded-t-lg' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                📊 Visão Geral
              </button>
              <button
                onClick={() => setActiveAdminTab('mediums')}
                className={`py-3 px-4 font-bold border-b-2 transition-all cursor-pointer ${
                  activeAdminTab === 'mediums' 
                    ? 'border-amber-600 text-amber-800 bg-amber-50/40 rounded-t-lg' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                🌿 Cadastro de Médiuns
              </button>
              <button
                onClick={() => setActiveAdminTab('fees')}
                className={`py-3 px-4 font-bold border-b-2 transition-all cursor-pointer ${
                  activeAdminTab === 'fees' 
                    ? 'border-amber-600 text-amber-800 bg-amber-50/40 rounded-t-lg' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                💳 Mensalidades e Caixa
              </button>
              <button
                onClick={() => setActiveAdminTab('events')}
                className={`py-3 px-4 font-bold border-b-2 transition-all cursor-pointer ${
                  activeAdminTab === 'events' 
                    ? 'border-amber-600 text-amber-800 bg-amber-50/40 rounded-t-lg' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                📅 Eventos e Cobranças
              </button>
              <button
                onClick={() => setActiveAdminTab('expenses')}
                className={`py-3 px-4 font-bold border-b-2 transition-all cursor-pointer ${
                  activeAdminTab === 'expenses' 
                    ? 'border-amber-600 text-amber-800 bg-amber-50/40 rounded-t-lg' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                💸 Contas a Pagar
              </button>
            </div>

            {/* Admin Tabs Sections */}
            {activeAdminTab === 'overview' && (
              <div className="space-y-6 animate-fade-in">
                <DashboardStats 
                  fees={fees} 
                  mediums={mediums} 
                  onNavigateToTab={(tab) => setActiveAdminTab(tab)} 
                />
              </div>
            )}

            {activeAdminTab === 'mediums' && (
              <div className="space-y-6 animate-fade-in">
                <div className="space-y-1">
                  <h3 className="text-lg font-bold text-slate-900">🌿 Livro de Registro da Corrente</h3>
                  <p className="text-xs text-slate-400">Adicione novos adeptos, atualize mensalidades contratuais e confira obrigações financeiras individuais.</p>
                </div>
                <MediumList
                  mediums={mediums}
                  fees={fees}
                  onAddMedium={() => setShowAddMediumModal(true)}
                  onEditMedium={(m) => setEditingMedium(m)}
                  onDeleteMedium={handleDeleteMedium}
                  onIssueFee={handleIssueFee}
                />
              </div>
            )}

            {activeAdminTab === 'fees' && (
              <div className="space-y-6 animate-fade-in">
                <div className="space-y-1">
                  <h3 className="text-lg font-bold text-slate-900">💳 Livro de Caixa e Mensalidades</h3>
                  <p className="text-xs text-slate-400">Confirme depósitos, execute baixas rápidas ou gere mensalidades pendentes para toda a corrente em lote.</p>
                </div>
                <FeesList
                  fees={fees}
                  mediums={mediums}
                  onUpdateFeeStatus={handleUpdateFeeStatus}
                  onDeleteFee={handleDeleteFee}
                  onBulkGenerateFees={handleBulkGenerateFees}
                />
              </div>
            )}

            {activeAdminTab === 'events' && (
              <div className="space-y-6 animate-fade-in">
                <EventsManagement
                  events={events}
                  mediums={mediums}
                  fees={fees}
                  onCreateEvent={handleCreateEvent}
                  onLaunchEventFees={handleLaunchEventFees}
                  onDeleteEvent={handleDeleteEvent}
                />
              </div>
            )}

            {activeAdminTab === 'expenses' && (
              <div className="space-y-6 animate-fade-in">
                <BillsPayableManagement
                  bills={bills}
                  fees={fees}
                  onCreateBill={handleCreateBill}
                  onUpdateBill={handleUpdateBill}
                  onDeleteBill={handleDeleteBill}
                />
              </div>
            )}

          </div>
        ) : (
          <div className="animate-fade-in max-w-4xl mx-auto space-y-4">
            <div className="space-y-1 text-center max-w-md mx-auto mb-3">
              <h3 className="text-lg font-bold text-slate-900">Portal do Filho de Fé</h3>
              <p className="text-xs text-slate-400">Atalho do aplicativo para que o médium consulte suas mensalidades abertas, emita o PIX ou visualize recibos impressos de pagamento.</p>
            </div>
            <MediumView
              mediums={mediums}
              fees={fees}
              onUploadComprovante={handleUploadComprovante}
              onSimulateInstantPay={handleSimulateInstantPay}
              initialMediumId={sessionMediumId}
              isPreLoggedIn={userSessionRole === 'medium'}
              onLogout={() => {
                if (userSessionRole === 'medium') {
                  setIsUserLoggedIn(false);
                  setUserSessionRole(null);
                  setSessionMediumId(null);
                } else {
                  setCurrentMode('admin');
                }
              }}
            />
          </div>
        )}

      </main>

      {/* Footer & Backup Options Panel */}
      <footer className="bg-white border-t border-amber-100 py-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="space-y-0.5 text-center md:text-left">
            <div><strong>TUPBAO - Mensalidade</strong> • Terreiro em dia</div>
            <div className="text-slate-400 font-medium">Guarde e administre com respeito todas as contribuições rituais do Templo.</div>
          </div>
          
          {/* Admin Database utilities */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleExportBackup}
              className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Salvar cópia de segurança completa do banco em JSON"
            >
              <FolderDown className="h-4 w-4" />
              Exportar JSON
            </button>
            <button
              onClick={handleResetData}
              className="bg-slate-50 hover:bg-rose-50 hover:text-rose-700 border border-slate-200 hover:border-rose-200 text-slate-500 px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer text-center"
              title="Zerar alterações e restaurar dados fictícios"
            >
              <RotateCcw className="h-4 w-4" />
              Resetar Banco Demo
            </button>
          </div>
        </div>
      </footer>

      {/* Medium Form modal (handles add/edit) */}
      {(showAddMediumModal || editingMedium) && (
        <MediumForm
          medium={editingMedium}
          nextSuggestedReg={getNextSuggestedReg()}
          onSave={handleSaveMedium}
          onClose={() => {
            setShowAddMediumModal(false);
            setEditingMedium(null);
          }}
        />
      )}

    </div>
  );
}
