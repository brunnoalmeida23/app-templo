/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Check, 
  Clock, 
  Calendar, 
  ShieldAlert, 
  DollarSign, 
  FileText, 
  Tag, 
  Search, 
  TrendingDown, 
  TrendingUp, 
  Filter, 
  Edit3, 
  Undo,
  CalendarCheck2
} from 'lucide-react';
import { BillPayable, MonthlyFee } from '../types';

interface BillsPayableManagementProps {
  bills: BillPayable[];
  fees: MonthlyFee[];
  onCreateBill: (billData: Omit<BillPayable, 'id'>) => void;
  onUpdateBill: (updatedBill: BillPayable) => void;
  onDeleteBill: (id: string) => void;
}

export const BillsPayableManagement: React.FC<BillsPayableManagementProps> = ({
  bills,
  fees,
  onCreateBill,
  onUpdateBill,
  onDeleteBill
}) => {
  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'pending'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingBill, setEditingBill] = useState<BillPayable | null>(null);
  
  // Inputs
  const [description, setDescription] = useState('');
  const [value, setValue] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [category, setCategory] = useState<BillPayable['category']>('outros');
  const [notes, setNotes] = useState('');
  
  // Quick payment modal or inputs
  const [payingBillId, setPayingBillId] = useState<string | null>(null);
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().slice(0, 10));

  // Category map helper for icons and names
  const categoryMeta: Record<BillPayable['category'], { label: string; bg: string; text: string }> = {
    energia: { label: 'Energia Elétrica', bg: 'bg-yellow-50 border-yellow-200', text: 'text-yellow-800' },
    agua: { label: 'Água / Saneamento', bg: 'bg-sky-50 border-sky-200', text: 'text-sky-800' },
    artigos: { label: 'Artigos Religiosos (Velas/Incenso)', bg: 'bg-purple-50 border-purple-200', text: 'text-purple-800' },
    reforma: { label: 'Manutenção / Reforma', bg: 'bg-amber-50 border-amber-200', text: 'text-amber-800' },
    limpeza: { label: 'Produtos de Limpeza', bg: 'bg-emerald-50 border-emerald-200', text: 'text-emerald-800' },
    outros: { label: 'Outras Despesas', bg: 'bg-slate-50 border-slate-200', text: 'text-slate-800' },
  };

  // Financial Stats of Bills & Inflow
  const totalPaidBills = bills.filter(b => b.status === 'paid').reduce((sum, b) => sum + b.value, 0);
  const totalPendingBills = bills.filter(b => b.status === 'pending').reduce((sum, b) => sum + b.value, 0);
  
  // Inflow from monthly fees
  const totalReceivedInflow = fees.filter(f => f.status === 'paid').reduce((sum, f) => sum + f.value, 0);
  const totalPendingInflow = fees.filter(f => f.status === 'pending' || f.status === 'overdue').reduce((sum, f) => sum + f.value, 0);
  
  // Real Net Cash Register (Arrecadado - Pago)
  const netCashFlow = totalReceivedInflow - totalPaidBills;

  // Filtered Bills
  const filteredBills = bills.filter(bill => {
    const matchesSearch = bill.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (bill.notes || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || bill.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || bill.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesCategory;
  }).sort((a, b) => b.dueDate.localeCompare(a.dueDate)); // Newest dueDate or closest first

  // Submit Handler for Adding/Editing
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || !value || !dueDate) {
      alert("Por favor, preencha todos os campos obrigatórios.");
      return;
    }

    const numericalValue = parseFloat(value);
    if (isNaN(numericalValue) || numericalValue <= 0) {
      alert("Por favor, insira um valor válido maior que zero.");
      return;
    }

    if (editingBill) {
      onUpdateBill({
        ...editingBill,
        description,
        value: numericalValue,
        dueDate,
        category,
        notes: notes.trim() || undefined
      });
      setEditingBill(null);
    } else {
      onCreateBill({
        description,
        value: numericalValue,
        dueDate,
        category,
        status: 'pending',
        paymentDate: null,
        notes: notes.trim() || undefined
      });
    }

    // Reset Form
    setDescription('');
    setValue('');
    setDueDate('');
    setCategory('outros');
    setNotes('');
    setShowAddForm(false);
  };

  // Populate form for editing
  const handleStartEdit = (bill: BillPayable) => {
    setEditingBill(bill);
    setDescription(bill.description);
    setValue(String(bill.value));
    setDueDate(bill.dueDate);
    setCategory(bill.category);
    setNotes(bill.notes || '');
    setShowAddForm(true);
  };

  // Quick mark paid
  const handleMarkAsPaid = (id: string) => {
    const bill = bills.find(b => b.id === id);
    if (!bill) return;

    onUpdateBill({
      ...bill,
      status: 'paid',
      paymentDate: paymentDate || new Date().toISOString().slice(0, 10)
    });
    setPayingBillId(null);
  };

  // Mark back to pending
  const handleMarkAsPending = (id: string) => {
    const bill = bills.find(b => b.id === id);
    if (!bill) return;

    if (confirm("Deseja reverter o pagamento e marcar esta conta como PENDENTE?")) {
      onUpdateBill({
        ...bill,
        status: 'pending',
        paymentDate: null
      });
    }
  };

  const handleOpenPaymentQuickModal = (id: string) => {
    setPayingBillId(id);
    setPaymentDate(new Date().toISOString().slice(0, 10));
  };

  // Currency Formatter
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  // Date Formatter Helper
  const formatDateBR = (dateStr: string) => {
    return dateStr.split('-').reverse().join('/');
  };

  return (
    <div className="space-y-6">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-amber-100 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-rose-700 font-bold mb-1">
            <TrendingDown className="h-5 w-5" />
            <span className="text-xs uppercase tracking-widest font-extrabold">Gestão Financeira Avançada</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">💸 Contas a Pagar e Saídas</h2>
          <p className="text-xs text-slate-500 mt-1">
            Controle o fluxo de despesas e custos do terreiro para uma conciliação transparente de caixa em tempo real.
          </p>
        </div>
        <button
          onClick={() => {
            setEditingBill(null);
            setDescription('');
            setValue('');
            setDueDate('');
            setCategory('outros');
            setNotes('');
            setShowAddForm(!showAddForm);
          }}
          className="bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs px-4 py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm hover:scale-[1.02] cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          REGISTRAR NOVA CONTA
        </button>
      </div>

      {/* Dynamic Financial Overview Panel - cash flow simulator */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Card Outflow Status */}
        <div className="bg-white rounded-2xl p-5 border border-rose-100 shadow-xs relative overflow-hidden">
          <div className="absolute top-0 right-0 h-16 w-16 bg-rose-50 rounded-full translate-x-4 -translate-y-4" />
          <div className="flex items-center justify-between mb-3 relative z-10">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Saídas do Terreiro</span>
            <span className="text-rose-600 bg-rose-50 text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full border border-rose-100 uppercase">
              Despesas Gastas
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex items-baseline justify-between">
              <span className="text-[11px] text-slate-400 font-medium">Pago:</span>
              <span className="text-base font-bold text-rose-700 font-mono">{formatCurrency(totalPaidBills)}</span>
            </div>
            <div className="flex items-baseline justify-between border-b border-dashed border-slate-100 pb-2">
              <span className="text-[11px] text-slate-400 font-medium">Pendente a Pagar:</span>
              <span className="text-base font-bold text-amber-600 font-mono">{formatCurrency(totalPendingBills)}</span>
            </div>
            <div className="flex items-baseline justify-between pt-1 font-bold">
              <span className="text-[11px] text-slate-600">Total Provisionado:</span>
              <span className="text-base font-extrabold text-slate-800 font-mono">{formatCurrency(totalPaidBills + totalPendingBills)}</span>
            </div>
          </div>
        </div>

        {/* Card Inflow Status */}
        <div className="bg-white rounded-2xl p-5 border border-emerald-100 shadow-xs relative overflow-hidden">
          <div className="absolute top-0 right-0 h-16 w-16 bg-emerald-50 rounded-full translate-x-4 -translate-y-4" />
          <div className="flex items-center justify-between mb-3 relative z-10">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Entradas (Arrecadação)</span>
            <span className="text-emerald-700 bg-emerald-50 text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full border border-emerald-100 uppercase">
              Mensalidades & Taxas
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex items-baseline justify-between">
              <span className="text-[11px] text-slate-400 font-medium">Recebidas:</span>
              <span className="text-base font-bold text-emerald-700 font-mono">{formatCurrency(totalReceivedInflow)}</span>
            </div>
            <div className="flex items-baseline justify-between border-b border-dashed border-slate-100 pb-2">
              <span className="text-[11px] text-slate-400 font-medium">A Receber:</span>
              <span className="text-base font-bold text-amber-600 font-mono">{formatCurrency(totalPendingInflow)}</span>
            </div>
            <div className="flex items-baseline justify-between pt-1 font-bold">
              <span className="text-[11px] text-slate-600">Total Estimado Inflow:</span>
              <span className="text-base font-extrabold text-slate-800 font-mono">{formatCurrency(totalReceivedInflow + totalPendingInflow)}</span>
            </div>
          </div>
        </div>

        {/* Card Box Balance (Cash Flow) */}
        <div className={`rounded-2xl p-5 border shadow-xs relative overflow-hidden ${
          netCashFlow >= 0 ? 'bg-emerald-50/50 border-emerald-200' : 'bg-rose-50/40 border-rose-200'
        }`}>
          <div className="absolute top-0 right-0 h-16 w-16 bg-white/40 rounded-full translate-x-4 -translate-y-4" />
          <div className="flex items-center justify-between mb-3 relative z-10">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-widest">Saldo Real de Caixa</span>
            <div className={`p-1.5 rounded-lg shrink-0 ${netCashFlow >= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
              {netCashFlow >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
            </div>
          </div>
          <div className="mt-2">
            <span className="text-xs text-slate-500 font-medium">Caixa Atual (Mensalidades Recebidas - Despesas Pagas):</span>
            <h3 className={`text-2xl sm:text-3xl font-black font-mono tracking-tight mt-1 ${
              netCashFlow >= 0 ? 'text-emerald-700' : 'text-rose-700'
            }`}>
              {formatCurrency(netCashFlow)}
            </h3>
            <p className="text-[10px] text-slate-400 mt-1 font-semibold uppercase tracking-wider">
              {netCashFlow >= 0 ? '✓ Terreiro operando no superavit' : '⚠ Atenção: Caixa atual negativo!'}
            </p>
          </div>
        </div>

      </div>

      {/* Bill creation / edit form (slide-down effect on component toggle) */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 border border-amber-200 shadow-md animate-fade-in space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <FileText className="h-4 w-4 text-rose-600" />
              {editingBill ? '✏️ Editar Lançamento de Conta' : '📝 Registrar Nova Despesa do Terreiro'}
            </h4>
            <button
              type="button"
              onClick={() => {
                setShowAddForm(false);
                setEditingBill(null);
              }}
              className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              Cancelar
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            
            {/* Description row - takes 2 spots */}
            <div className="md:col-span-2 space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                Descrição da Conta / Prestador *
              </label>
              <input
                type="text"
                placeholder="Ex. Conta de Luz (Enel), Compra de Incensos..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full text-slate-800 text-sm p-2.5 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-hidden"
                required
              />
            </div>

            {/* Value input */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                Valor Cobrado (R$) *
              </label>
              <input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                className="w-full text-slate-800 text-sm p-2.5 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-hidden font-mono"
                required
              />
            </div>

            {/* Due date input */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                Data Vencimento *
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full text-slate-800 text-sm p-2.5 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-hidden font-mono"
                required
              />
            </div>

            {/* Category row */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                Categoria da Despesa
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as BillPayable['category'])}
                className="w-full text-slate-800 text-sm p-2.5 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-hidden"
              >
                <option value="energia">Energia Elétrica (Luz)</option>
                <option value="agua">Água / Saneamento</option>
                <option value="artigos">Artigos Religiosos (Velas/Incenso)</option>
                <option value="reforma">Manutenção / Reforma</option>
                <option value="limpeza">Produtos de Limpeza</option>
                <option value="outros">Outros Afins</option>
              </select>
            </div>

            {/* Notes row - takes remaining space */}
            <div className="md:col-span-3 space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                Observações Adicionais / Recibos
              </label>
              <input
                type="text"
                placeholder="Ex. Pago com Pix da conta poupança ou referente à manutenção do bebedouro..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full text-slate-800 text-sm p-2.5 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-hidden"
              />
            </div>

          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                setShowAddForm(false);
                setEditingBill(null);
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl text-xs transition-colors cursor-pointer shadow-xs"
            >
              {editingBill ? 'SALVAR ALTERAÇÕES' : 'CONFIRMAR REGISTRO'}
            </button>
          </div>
        </form>
      )}

      {/* FILTER CONTROLS AND LIST */}
      <div className="bg-white rounded-2xl border border-amber-100 shadow-xs overflow-hidden">
        
        {/* Filter bar */}
        <div className="p-4 bg-slate-50/50 border-b border-slate-100 grid grid-cols-1 md:grid-cols-4 gap-3">
          
          {/* Search Box */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Buscar despesa ou nota..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-white rounded-xl border border-slate-200 focus:border-amber-600 outline-hidden text-slate-800 focus:ring-1 focus:ring-amber-600"
            />
          </div>

          {/* Status filter */}
          <div className="flex items-center gap-2">
            <Filter className="h-3.5 w-3.5 text-slate-400 shrink-0" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full py-2 px-3 text-xs bg-white rounded-xl border border-slate-200 focus:border-amber-600 outline-hidden text-slate-800"
            >
              <option value="all">Todos os Status (Ambos)</option>
              <option value="pending">Contas Pendentes</option>
              <option value="paid">Contas Pagas</option>
            </select>
          </div>

          {/* Category filter */}
          <div className="flex items-center gap-2">
            <Tag className="h-3.5 w-3.5 text-slate-400 shrink-0" />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs bg-white rounded-xl border border-slate-200 focus:border-amber-600 outline-hidden text-slate-800"
            >
              <option value="all">Todas as Categorias</option>
              <option value="energia">Energia Elétrica (Luz)</option>
              <option value="agua">Água / Saneamento</option>
              <option value="artigos">Artigos Religiosos (Velas/Incenso)</option>
              <option value="reforma">Manutenção / Reforma</option>
              <option value="limpeza">Produtos de Limpeza</option>
              <option value="outros">Outros Afins</option>
            </select>
          </div>

          {/* Count label */}
          <div className="flex items-center justify-end text-xs font-semibold text-slate-500">
            {filteredBills.length} {filteredBills.length === 1 ? 'conta listada' : 'contas listadas'}
          </div>

        </div>

        {/* Quick payment helper panel if select paying */}
        {payingBillId && (
          <div className="bg-rose-50 border-b border-rose-100 p-4 animate-fade-in flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs text-rose-900">
              <span className="font-extrabold flex items-center gap-1.5">
                <Calendar className="h-4 w-4 shrink-0 text-rose-700" />
                Informe a data de pagamento para dar baixa:
              </span>
              <p className="mt-0.5 font-medium text-rose-800/80">
                Lançamento: "{bills.find(b => b.id === payingBillId)?.description}"
              </p>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="bg-white border border-rose-300 text-slate-800 text-xs py-1.5 px-3 rounded-lg outline-hidden font-mono"
              />
              <button
                onClick={() => handleMarkAsPaid(payingBillId)}
                className="bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[11px] px-3 py-2 rounded-lg transition-colors cursor-pointer"
              >
                Confirmar Baixa
              </button>
              <button
                onClick={() => setPayingBillId(null)}
                className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-[11px] px-2.5 py-2 rounded-lg transition-colors cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}

        {/* Table list */}
        <div className="overflow-x-auto">
          {filteredBills.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-2">
              <FileText className="h-10 w-10 text-slate-300 mx-auto" />
              <h5 className="text-sm font-bold text-slate-700">Nenhuma despesa encontrada</h5>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Tente ajustar os filtros, pesquisar por outro termo ou registre um novo lançamento clicando em "Registrar Nova Conta" acima.
              </p>
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-400 text-[10px] font-bold uppercase tracking-wider border-b border-slate-100">
                  <th className="py-3 px-4">Descrição da Conta</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Vencimento</th>
                  <th className="py-3 px-4 text-right">Valor</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4">Pgo. em</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 text-xs font-sans">
                {filteredBills.map(bill => {
                  const meta = categoryMeta[bill.category] || categoryMeta.outros;
                  const isPaid = bill.status === 'paid';
                  const isOverdue = !isPaid && new Date(bill.dueDate + 'T23:59:59') < new Date();

                  return (
                    <tr key={bill.id} className="hover:bg-slate-50/50 transition-colors">
                      {/* Name & Notes */}
                      <td className="py-3.5 px-4 max-w-[280px]">
                        <div className="font-bold text-slate-800 line-clamp-1">
                          {bill.description}
                        </div>
                        {bill.notes && (
                          <div className="text-[10px] text-slate-400 italic line-clamp-1 mt-0.5">
                            {bill.notes}
                          </div>
                        )}
                      </td>

                      {/* Category Label */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md border ${meta.bg} ${meta.text}`}>
                          {meta.label}
                        </span>
                      </td>

                      {/* Due date */}
                      <td className="py-3.5 px-4 whitespace-nowrap font-semibold font-mono">
                        <span className={isOverdue ? 'text-rose-600 font-bold' : ''}>
                          {formatDateBR(bill.dueDate)}
                        </span>
                      </td>

                      {/* Money value */}
                      <td className="py-3.5 px-4 text-right font-extrabold text-slate-800 whitespace-nowrap font-mono">
                        {formatCurrency(bill.value)}
                      </td>

                      {/* Status indicator badge */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        {isPaid ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-full uppercase tracking-wider">
                            <Check className="h-3 w-3 text-emerald-700" />
                            Pago
                          </span>
                        ) : isOverdue ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-full uppercase tracking-wider">
                            <ShieldAlert className="h-3 w-3 text-rose-600" />
                            Atrasado
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-full uppercase tracking-wider">
                            <Clock className="h-3 w-3 text-amber-600" />
                            Pendente
                          </span>
                        )}
                      </td>

                      {/* Payment Date */}
                      <td className="py-3.5 px-4 whitespace-nowrap font-mono text-slate-500 font-medium">
                        {bill.paymentDate ? formatDateBR(bill.paymentDate) : '—'}
                      </td>

                      {/* Action buttons */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          
                          {/* Complete bill toggle */}
                          {isPaid ? (
                            <button
                              onClick={() => handleMarkAsPending(bill.id)}
                              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 rounded-md transition-colors cursor-pointer"
                              title="Marcar como pendente (estornar)"
                            >
                              <Undo className="h-3.5 w-3.5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleOpenPaymentQuickModal(bill.id)}
                              className="p-1 px-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10.5px] font-extrabold rounded-md flex items-center gap-0.5 border border-rose-200/50 transition-colors cursor-pointer scale-98 active:scale-95"
                              title="Pagar despesa do caixa"
                            >
                              <CalendarCheck2 className="h-3 w-3" />
                              Baixar Pago
                            </button>
                          )}

                          {/* Edit button */}
                          <button
                            onClick={() => handleStartEdit(bill)}
                            className="p-1.5 bg-slate-100 hover:bg-amber-50 hover:text-amber-700 text-slate-500 rounded-md transition-colors cursor-pointer"
                            title="Editar lançamento"
                          >
                            <Edit3 className="h-3.5 w-3.5" />
                          </button>

                          {/* Delete button */}
                          <button
                            onClick={() => {
                              if (confirm(`Excluir lançamento de "${bill.description}" permanentemente do sistema?`)) {
                                onDeleteBill(bill.id);
                              }
                            }}
                            className="p-1.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-500 rounded-md transition-colors cursor-pointer"
                            title="Deletar despesa"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>

                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

      </div>

    </div>
  );
};
