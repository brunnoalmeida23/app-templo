/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DollarSign, AlertTriangle, Clock, TrendingUp, CheckCircle, Users } from 'lucide-react';
import { MonthlyFee, PaymentStats, Medium } from '../types';
import { getStats } from '../data';

interface DashboardStatsProps {
  fees: MonthlyFee[];
  mediums: Medium[];
  onNavigateToTab: (tab: string) => void;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({ fees, mediums, onNavigateToTab }) => {
  const stats = getStats(fees);
  const activeMediumsCount = mediums.filter(m => m.active).length;

  // Group fees by month to render an aesthetic breakdown
  const months = Array.from(new Set(fees.map(f => f.referenceMonth))).sort() as string[];
  
  const monthBreakdowns = months.map(month => {
    const monthFees = fees.filter(f => f.referenceMonth === month);
    const paid = monthFees.filter(f => f.status === 'paid').reduce((sum, f) => sum + f.value, 0);
    const pending = monthFees.filter(f => f.status === 'pending').reduce((sum, f) => sum + f.value, 0);
    const overdue = monthFees.filter(f => f.status === 'overdue').reduce((sum, f) => sum + f.value, 0);
    const total = paid + pending + overdue;
    const paidPercentage = total > 0 ? (paid / total) * 100 : 0;
    const pendingPercentage = total > 0 ? (pending / total) * 100 : 0;
    const overduePercentage = total > 0 ? (overdue / total) * 100 : 0;

    // Portuguese description
    const [year, m] = month.split('-');
    const monthsNames: { [key: string]: string } = {
      '01': 'Jan', '02': 'Fev', '03': 'Mar', '04': 'Abr', '05': 'Mai', '06': 'Jun',
      '07': 'Jul', '08': 'Ago', '09': 'Set', '10': 'Out', '11': 'Nov', '12': 'Dez'
    };
    const label = `${monthsNames[m]}/${year.slice(2)}`;

    return {
      monthKey: month,
      label,
      paid,
      pending,
      overdue,
      total,
      paidPercentage,
      pendingPercentage,
      overduePercentage
    };
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      {/* Cards stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Card 1 - Arrecadado */}
        <div className="bg-white rounded-xl p-5 border border-amber-100 shadow-xs hover:shadow-md transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 h-24 w-24 bg-emerald-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500 -z-10" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-slate-500 uppercase tracking-wider">Arrecadado</span>
            <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-lg">
              <CheckCircle className="h-5 w-5" />
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-800 tracking-tight">{formatCurrency(stats.totalCollected)}</h3>
            <p className="text-xs text-slate-400 mt-1">
              <span className="text-emerald-600 font-semibold">{stats.paidCount}</span> mensalidades recebidas
            </p>
          </div>
        </div>

        {/* Card 2 - Pendente */}
        <div className="bg-white rounded-xl p-5 border border-amber-100 shadow-xs hover:shadow-md transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 h-24 w-24 bg-amber-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500 -z-10" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-slate-500 uppercase tracking-wider">A Receber (No Prazo)</span>
            <div className="p-2.5 bg-amber-100 text-amber-700 rounded-lg">
              <Clock className="h-5 w-5" />
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-800 tracking-tight">{formatCurrency(stats.totalPending)}</h3>
            <p className="text-xs text-slate-400 mt-1">
              <span className="text-amber-600 font-semibold">{stats.pendingCount}</span> mensalidades em aberto
            </p>
          </div>
        </div>

        {/* Card 3 - Em Atraso */}
        <div className="bg-white rounded-xl p-5 border border-amber-100 shadow-xs hover:shadow-md transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 h-24 w-24 bg-rose-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500 -z-10" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-slate-500 uppercase tracking-wider">Em Atraso</span>
            <div className="p-2.5 bg-rose-100 text-rose-800 rounded-lg">
              <AlertTriangle className="h-5 w-5" />
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-rose-700 tracking-tight">{formatCurrency(stats.totalOverdue)}</h3>
            <p className="text-xs text-rose-500 mt-1 font-medium">
              <span>{stats.overdueCount}</span> pendentes vencidas
            </p>
          </div>
        </div>

        {/* Card 4 - Médiuns Ativos */}
        <div className="bg-white rounded-xl p-5 border border-amber-100 shadow-xs hover:shadow-md transition-all duration-300 relative overflow-hidden group" onClick={() => onNavigateToTab('mediums')} style={{ cursor: 'pointer' }}>
          <div className="absolute top-0 right-0 h-24 w-24 bg-slate-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500 -z-10" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-slate-500 uppercase tracking-wider">Médiuns Ativos</span>
            <div className="p-2.5 bg-slate-100 text-slate-700 rounded-lg">
              <Users className="h-5 w-5" />
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-800 tracking-tight">{activeMediumsCount}</h3>
            <p className="text-xs text-slate-400 mt-1">
              De {mediums.length} cadastrados no total
            </p>
          </div>
        </div>
      </div>

      {/* Visual Monthly Breakdown Chart */}
      <div className="bg-white rounded-xl p-6 border border-amber-100 shadow-xs">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-slate-800">Histórico Arrecadação por Mês</h3>
            <p className="text-xs text-slate-400">Distribuição financeira entre mensalidades pagas, pendentes e em atraso</p>
          </div>
          <div className="flex space-x-4 text-xs font-medium">
            <div className="flex items-center">
              <span className="w-3 h-3 bg-emerald-500 rounded-sm mr-1.5" />
              <span className="text-slate-600">Pago</span>
            </div>
            <div className="flex items-center">
              <span className="w-3 h-3 bg-amber-400 rounded-sm mr-1.5" />
              <span className="text-slate-600">Pendente</span>
            </div>
            <div className="flex items-center">
              <span className="w-3 h-3 bg-rose-500 rounded-sm mr-1.5" />
              <span className="text-slate-600">Atrasado</span>
            </div>
          </div>
        </div>

        {/* Visual Chart Bars */}
        <div className="space-y-5">
          {monthBreakdowns.map(month => (
            <div key={month.monthKey} className="group">
              <div className="flex justify-between items-center text-sm mb-1.5">
                <span className="font-semibold text-slate-700 min-w-[70px]">{month.label}</span>
                <span className="text-xs text-slate-400">
                  Total: <strong className="text-slate-600">{formatCurrency(month.total)}</strong>
                </span>
              </div>
              <div className="w-full bg-slate-100 h-7 rounded-sm flex overflow-hidden shadow-inner">
                {month.paid > 0 && (
                  <div
                    style={{ width: `${month.paidPercentage}%` }}
                    className="bg-emerald-500 hover:bg-emerald-600 transition-colors duration-200 flex items-center justify-center text-[10px] text-white font-bold truncate px-1"
                    title={`Pago: ${formatCurrency(month.paid)} (${month.paidPercentage.toFixed(1)}%)`}
                  >
                    {month.paidPercentage > 15 ? formatCurrency(month.paid) : ''}
                  </div>
                )}
                {month.pending > 0 && (
                  <div
                    style={{ width: `${month.pendingPercentage}%` }}
                    className="bg-amber-400 hover:bg-amber-500 transition-colors duration-200 flex items-center justify-center text-[10px] text-slate-800 font-bold truncate px-1"
                    title={`Pendente: ${formatCurrency(month.pending)} (${month.pendingPercentage.toFixed(1)}%)`}
                  >
                    {month.pendingPercentage > 15 ? formatCurrency(month.pending) : ''}
                  </div>
                )}
                {month.overdue > 0 && (
                  <div
                    style={{ width: `${month.overduePercentage}%` }}
                    className="bg-rose-500 hover:bg-rose-600 transition-colors duration-200 flex items-center justify-center text-[10px] text-white font-bold truncate px-1"
                    title={`Atrasado: ${formatCurrency(month.overdue)} (${month.overduePercentage.toFixed(1)}%)`}
                  >
                    {month.overduePercentage > 15 ? formatCurrency(month.overdue) : ''}
                  </div>
                )}
                {month.total === 0 && (
                  <div className="w-full text-slate-400 flex items-center justify-center text-xs italic">
                    Sem lançamentos neste mês
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick helpful instructions */}
      <div className="bg-amber-50/50 rounded-xl p-4 border border-amber-100/70 flex items-start gap-3">
        <TrendingUp className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="text-sm font-semibold text-amber-800">Conselho de Gestão</h4>
          <p className="text-xs text-amber-700/90 leading-relaxed mt-0.5">
            Ao se aproximar do dia 10 (vencimento padrão), envie lembretes aos médiuns. Na aba <strong>Mensalidades</strong>, você pode emitir facilmente os débitos em lote para todos os médiuns ativos de uma só vez, ou conferir comprovantes que foram submetidos pelos médiuns para aprovação!
          </p>
        </div>
      </div>
    </div>
  );
};
