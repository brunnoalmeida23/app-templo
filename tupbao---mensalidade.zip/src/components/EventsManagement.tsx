/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Calendar, DollarSign, PlusCircle, CheckCircle, Clock, Sparkles, AlertCircle, RefreshCw, Trash2, Tag, Info } from 'lucide-react';
import { TerreiroEvent, Medium, MonthlyFee } from '../types';

interface EventsManagementProps {
  events: TerreiroEvent[];
  mediums: Medium[];
  fees: MonthlyFee[];
  onCreateEvent: (event: Omit<TerreiroEvent, 'id' | 'billingIssued'>) => void;
  onLaunchEventFees: (eventId: string) => void;
  onDeleteEvent?: (id: string) => void;
}

export const EventsManagement: React.FC<EventsManagementProps> = ({
  events,
  mediums,
  fees,
  onCreateEvent,
  onLaunchEventFees,
  onDeleteEvent
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');
  const [costPerMedium, setCostPerMedium] = useState<number>(30);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const activeMediumsCount = mediums.filter(m => m.active).length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!name.trim()) {
      setErrorMsg('O nome do evento é obrigatório.');
      return;
    }
    if (!description.trim()) {
      setErrorMsg('A descrição do evento é obrigatória.');
      return;
    }
    if (costPerMedium <= 0) {
      setErrorMsg('O custo por médium deve ser maior que R$ 0.');
      return;
    }

    onCreateEvent({
      name: name.trim(),
      date,
      description: description.trim(),
      costPerMedium
    });

    setSuccessMsg('Evento registrado com sucesso!');
    setName('');
    setDescription('');
    setCostPerMedium(30);
    setShowAddForm(false);

    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const handleLaunch = (eventId: string, eventName: string) => {
    if (confirm(`Deseja lançar a taxa deste evento para todos os ${activeMediumsCount} médiuns ativos agora?`)) {
      onLaunchEventFees(eventId);
      setSuccessMsg(`Taxas do evento "${eventName}" lançadas com sucesso para todos os médiuns ativos!`);
      setTimeout(() => setSuccessMsg(''), 5000);
    }
  };

  const getEventStats = (eventName: string) => {
    const eventFees = fees.filter(f => f.isEventFee && f.eventName === eventName);
    const totalBills = eventFees.length;
    const paidBills = eventFees.filter(f => f.status === 'paid').length;
    const totalCollected = eventFees.filter(f => f.status === 'paid').reduce((acc, f) => acc + f.value, 0);
    const totalExpected = eventFees.reduce((acc, f) => acc + f.value, 0);

    return {
      totalBills,
      paidBills,
      totalCollected,
      totalExpected
    };
  };

  return (
    <div className="space-y-6">
      
      {/* Upper info panel */}
      <div className="bg-slate-950 text-white rounded-2xl p-6 bg-radial from-slate-900 to-slate-950 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center md:text-left">
          <div className="flex justify-center md:justify-start items-center gap-1 text-amber-400 font-bold text-xs uppercase tracking-wider">
            <Sparkles className="h-4 w-4" />
            Taxas Extraordinárias
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight">Eventos e Contribuições Esporádicas</h2>
          <p className="text-xs text-slate-300 max-w-xl leading-normal">
            Cadastre eventos especiais, reformas ou materiais ritualísticos (flores, velas, fardas, festividades) que demandam rateio esporádico entre o corpo mediúnico d&apos;água e de fogo.
          </p>
        </div>
        <button
          onClick={() => {
            setShowAddForm(!showAddForm);
            setErrorMsg('');
          }}
          className="bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-5 rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shrink-0 self-stretch sm:self-center justify-center"
        >
          <PlusCircle className="h-4.5 w-4.5" />
          {showAddForm ? 'Fechar Formulário' : 'Novo Evento de Cobrança'}
        </button>
      </div>

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold rounded-xl text-xs flex items-center gap-2 animate-fade-in shadow-xs">
          <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0" />
          {successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 font-bold rounded-xl text-xs flex items-center gap-2 animate-fade-in shadow-xs">
          <AlertCircle className="h-5 w-5 text-rose-500 shrink-0" />
          {errorMsg}
        </div>
      )}

      {/* Adding event form */}
      {showAddForm && (
        <div className="bg-white border border-amber-100 rounded-2xl shadow-md p-6 animate-fade-in">
          <h3 className="text-base font-extrabold text-slate-900 border-b border-slate-100 pb-3 mb-4">
            🌿 Registrar Novo Evento de Rateio
          </h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            <div className="md:col-span-2 space-y-1.5">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">
                Nome do Evento / Finalidade
              </label>
              <input
                type="text"
                placeholder="Ex: Cerimônia Anual de Iemanjá, Compra de Alimentos Cosme e Damião"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 text-sm py-3 px-4 rounded-xl outline-hidden focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-medium text-slate-800"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">
                Data Estimada
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 text-sm py-3 px-4 rounded-xl outline-hidden focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all text-slate-800"
              />
            </div>

            <div className="md:col-span-2 space-y-1.5">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">
                Descrição ou Motivo da Cobrança
              </label>
              <textarea
                rows={2}
                placeholder="Explique com carinho e detalhamento onde será investido este valor..."
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 text-sm py-2.5 px-4 rounded-xl outline-hidden focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all text-slate-800 leading-normal"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">
                Mensalidade de Apoio / Custo Individual
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-sm font-bold text-slate-400">R$</span>
                <input
                  type="number"
                  min="1"
                  step="5"
                  value={costPerMedium}
                  onChange={e => setCostPerMedium(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 text-sm py-3 pl-10 pr-4 rounded-xl outline-hidden focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-semibold text-slate-800"
                />
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Billed to {activeMediumsCount} active mediums ({activeMediumsCount * costPerMedium} BRL total)</p>
            </div>

            <div className="md:col-span-3 flex justify-end gap-2.5 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold px-4 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs shadow-xs transition-colors cursor-pointer"
              >
                Confirmar Registro
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Events loop list */}
      <div className="grid grid-cols-1 gap-4">
        {events.length === 0 ? (
          <div className="bg-white border border-amber-100 rounded-3xl p-10 text-center space-y-3">
            <span className="text-4xl">🌻</span>
            <h3 className="text-base font-bold text-slate-700">Nenhum evento registrado</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Eventos cadastrados auxiliam em obras, manutenção e compras da casa. Clique em "Novo Evento" no canto superior direito para agendar um rateio.
            </p>
          </div>
        ) : (
          events.map(event => {
            const stats = getEventStats(event.name);
            const rawDate = new Date(event.date + 'T12:00:00');
            const formattedDate = rawDate.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });

            return (
              <div key={event.id} className="bg-white border border-amber-100 rounded-3xl p-6 shadow-xs flex flex-col md:flex-row gap-6 justify-between items-start md:items-center relative overflow-hidden transition-all hover:shadow-md">
                
                {/* Visual badge indicator inside card */}
                <div className={`absolute top-0 right-0 w-2 h-full ${event.billingIssued ? 'bg-emerald-500' : 'bg-amber-400'}`} />

                <div className="space-y-2.5 flex-1 max-w-xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="bg-slate-50 hover:bg-slate-100 text-slate-500 border border-slate-200 text-[10px] font-bold py-0.5 px-2.5 rounded-full flex items-center gap-1 uppercase tracking-wider">
                      <Tag className="h-3 w-3 text-amber-500" />
                      Extraordinária
                    </span>

                    {event.billingIssued ? (
                      <span className="bg-emerald-50 text-emerald-700 border border-emerald-100 text-[10px] font-bold py-0.5 px-2.5 rounded-full flex items-center gap-1 uppercase tracking-wider">
                        <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                        Lançamento Efetuado
                      </span>
                    ) : (
                      <span className="bg-amber-50 text-amber-700 border border-amber-100 text-[10px] font-bold py-0.5 px-2.5 rounded-full flex items-center gap-1 uppercase tracking-wider">
                        <Clock className="h-3.5 w-3.5 text-amber-500 text-amber-600 animate-spin" />
                        Aguardando Emissão
                      </span>
                    )}
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-lg font-bold text-slate-900 tracking-tight">{event.name}</h3>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                      <Calendar className="h-3.5 w-3.5 text-slate-400" />
                      <span>{formattedDate}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500 leading-normal font-medium">{event.description}</p>
                  
                  {event.billingIssued && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50/50 rounded-2xl border border-slate-100 p-3 mt-1.5">
                      <div>
                        <div className="text-[10px] uppercase font-bold text-slate-400">Total Rateado</div>
                        <div className="text-xs font-bold text-slate-800 font-mono">R$ {stats.totalExpected.toFixed(2)}</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase font-bold text-slate-400">Filhos Cobrados</div>
                        <div className="text-xs font-bold text-slate-800 font-mono">{stats.totalBills}</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase font-bold text-slate-400">Quitados</div>
                        <div className="text-xs font-bold text-emerald-700 font-mono">{stats.paidBills} de {stats.totalBills}</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase font-bold text-slate-400">Total Pago</div>
                        <div className="text-xs font-bold text-emerald-700 font-mono">R$ {stats.totalCollected.toFixed(2)}</div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-4 border-t md:border-t-0 border-slate-100 pt-4 md:pt-0 w-full md:w-auto shrink-0 self-stretch md:self-auto">
                  
                  <div className="text-left md:text-right">
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">Rateio por Médium</span>
                    <span className="text-2xl font-black text-amber-600 font-mono tracking-tight">
                      R$ {event.costPerMedium.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    {!event.billingIssued ? (
                      <button
                        onClick={() => handleLaunch(event.id, event.name)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1.5 hover:scale-[1.02]"
                      >
                        <DollarSign className="h-4 w-4" />
                        Lançar Taxa R$ {event.costPerMedium}
                      </button>
                    ) : (
                      <div className="bg-slate-100 border border-slate-200 text-slate-500 text-xs font-bold px-3 py-2 rounded-xl flex items-center gap-1">
                        <CheckCircle className="h-4.5 w-4.5 text-emerald-600" />
                        Cobrado
                      </div>
                    )}

                    {onDeleteEvent && (
                      <button
                        onClick={() => {
                          if (confirm(`Tem certeza que de seja excluir o evento "${event.name}"?`)) {
                            onDeleteEvent(event.id);
                          }
                        }}
                        className="p-2.5 bg-slate-50 hover:bg-rose-50 text-slate-400 hover:text-rose-600 border border-slate-200 hover:border-rose-100 rounded-xl transition-all cursor-pointer"
                        title="Excluir Evento"
                      >
                        <Trash2 className="h-4.5 w-4.5" />
                      </button>
                    )}
                  </div>

                </div>

              </div>
            );
          })
        )}
      </div>

      <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-200/50 flex gap-3 text-xs text-amber-900 leading-normal">
        <Info className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <strong>Sobre as cobranças extraordinárias:</strong> Ao clicar em <code className="bg-amber-100 font-mono text-[11px] font-bold px-1 rounded">Lançar Taxa</code>, o sistema criará guias de pagamento pendentes correspondentes ao evento para <strong>todos os médiuns com cadastro ativo</strong> no momento da emissão. Elas estarão visíveis imediatamente para pagamento nos portais individuais de cada filho de fé.
        </div>
      </div>

    </div>
  );
};
