/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, Calendar, CheckSquare, XSquare, PlusSquare, AlertTriangle, CheckCircle, Clock, Trash2, Eye, FileText, Check } from 'lucide-react';
import { MonthlyFee, Medium, FeeStatus } from '../types';
import { getPortgueseMonthName } from '../data';

interface FeesListProps {
  fees: MonthlyFee[];
  mediums: Medium[];
  onUpdateFeeStatus: (feeId: string, status: FeeStatus, paymentMethod?: any) => void;
  onDeleteFee: (feeId: string) => void;
  onBulkGenerateFees: (referenceMonth: string) => void;
}

export const FeesList: React.FC<FeesListProps> = ({
  fees,
  mediums,
  onUpdateFeeStatus,
  onDeleteFee,
  onBulkGenerateFees
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | FeeStatus>('all');
  const [monthFilter, setMonthFilter] = useState('all');
  
  // Bulk generate modal
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [bulkMonth, setBulkMonth] = useState('2026-06');

  // Detail modal (e.g. proof of payment simulation review)
  const [selectedFeeForReview, setSelectedFeeForReview] = useState<MonthlyFee | null>(null);

  // Months lists for dropdown filter
  const months = Array.from(new Set(fees.map(f => f.referenceMonth))).sort().reverse() as string[];

  // Filter fees
  const filteredFees = fees.filter(fee => {
    const matchesSearch = fee.mediumName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' ? true : fee.status === statusFilter;
    const matchesMonth = monthFilter === 'all' ? true : fee.referenceMonth === monthFilter;

    return matchesSearch && matchesStatus && matchesMonth;
  });

  const getStatusBadge = (status: FeeStatus) => {
    switch (status) {
      case 'paid':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
            Pago
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
            <Clock className="h-3.5 w-3.5 text-amber-600" />
            Pendente
          </span>
        );
      case 'overdue':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200 animate-pulse">
            <AlertTriangle className="h-3.5 w-3.5 text-rose-600" />
            Vencido
          </span>
        );
    }
  };

  const handleBulkGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    onBulkGenerateFees(bulkMonth);
    setShowBulkModal(false);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      {/* Filters and Actions */}
      <div className="bg-white rounded-xl p-4 border border-amber-100 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 flex-1">
          {/* Quick search */}
          <div className="relative flex-1">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search className="h-4 w-4" />
            </span>
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Buscar por nome do médium..."
              className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-lg py-2.5 pl-10 pr-4 text-sm outline-hidden transition-all focus:ring-2 focus:ring-amber-200"
            />
          </div>

          {/* Month selector filter */}
          <select
            value={monthFilter}
            onChange={e => setMonthFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-lg text-sm px-3 py-2.5 text-slate-700 outline-hidden focus:ring-2 focus:ring-amber-200"
          >
            <option value="all">Filtro: Todos os meses</option>
            {months.map(m => (
              <option key={m} value={m}>{getPortgueseMonthName(m)}</option>
            ))}
          </select>

          {/* Status selector filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-lg text-sm px-3 py-2.5 text-slate-700 outline-hidden focus:ring-2 focus:ring-amber-200"
          >
            <option value="all">Filtro: Todos as situações</option>
            <option value="paid">Confirmados (Pagos)</option>
            <option value="pending">A vencer (Pendentes)</option>
            <option value="overdue">Em Atraso (Vencidos)</option>
          </select>
        </div>

        {/* Bulk generation button */}
        <button
          onClick={() => setShowBulkModal(true)}
          className="bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold px-4 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <PlusSquare className="h-4.5 w-4.5" />
          Gerar Mensalidades em Lote
        </button>
      </div>

      {/* Main audit table */}
      <div className="bg-white rounded-xl border border-amber-100 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 uppercase text-xs font-bold border-b border-amber-100/60">
                <th className="py-4 px-6">Mês de Referência</th>
                <th className="py-4 px-6">Nome do Médium</th>
                <th className="py-4 px-6 text-center">Vencimento</th>
                <th className="py-4 px-6 text-center">Valor</th>
                <th className="py-4 px-6 text-center">Situação</th>
                <th className="py-4 px-6">Histórico Pagto</th>
                <th className="py-4 px-6 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-700">
              {filteredFees.length > 0 ? (
                filteredFees.map(fee => {
                  return (
                    <tr key={fee.id} className="hover:bg-amber-50/20 transition-colors">
                      <td className="py-4 px-6 font-semibold text-slate-800">
                        {getPortgueseMonthName(fee.referenceMonth)}
                      </td>
                      <td className="py-4 px-6">
                        <div className="font-semibold text-slate-950">{fee.mediumName}</div>
                      </td>
                      <td className="py-4 px-6 text-center text-xs font-mono">
                        {fee.dueDate.split('-').reverse().join('/')}
                      </td>
                      <td className="py-4 px-6 text-center font-bold text-slate-800 font-mono">
                        {formatCurrency(fee.value)}
                      </td>
                      <td className="py-4 px-6 text-center">
                        <div className="flex flex-col items-center gap-1.5">
                          {getStatusBadge(fee.status)}
                          {fee.comprovanteUploaded && fee.status !== 'paid' && (
                            <span className="inline-flex items-center bg-blue-50 text-blue-700 font-medium text-[10px] px-1.5 py-0.5 rounded-sm border border-blue-200 animate-pulse">
                              Comprovante enviado!
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-6 text-xs text-slate-500">
                        {fee.status === 'paid' ? (
                          <div>
                            <div>Pago em: {fee.paymentDate?.split('-').reverse().join('/')}</div>
                            <div className="mt-0.5">Via: <span className="uppercase font-semibold text-[10px] bg-slate-100 px-1 py-0.5 rounded-sm text-slate-600">{fee.paymentMethod}</span></div>
                          </div>
                        ) : (
                          <div className="italic text-slate-400">---</div>
                        )}
                        {fee.notes && <div className="text-slate-400 mt-1 italic font-mono truncate max-w-[150px]">{fee.notes}</div>}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {/* If medium sent proof of payment, give special review action */}
                          {fee.comprovanteUploaded && fee.status !== 'paid' ? (
                            <button
                              onClick={() => setSelectedFeeForReview(fee)}
                              className="p-1 px-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-md flex items-center gap-1 transition-colors shadow-xs cursor-pointer"
                              title="Avaliar comprovante enviado"
                            >
                              <Eye className="h-3.5 w-3.5" />
                              Revisar
                            </button>
                          ) : fee.status !== 'paid' ? (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => {
                                  if (confirm(`Confirmar recebimento de R$ ${fee.value.toFixed(2)} em DINHEIRO ou PIX em mãos para ${fee.mediumName}?`)) {
                                    onUpdateFeeStatus(fee.id, 'paid', 'dinheiro');
                                  }
                                }}
                                className="p-1 px-2.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-600 text-xs font-semibold rounded-md transition-colors border border-slate-200 hover:border-emerald-300 cursor-pointer"
                                title="Dar baixa direta de pagamento"
                              >
                                Baixa
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                if (confirm(`Estornar pagamento de R$ ${fee.value.toFixed(2)} para ${fee.mediumName} e colocá-lo novamente como Pendente?`)) {
                                  onUpdateFeeStatus(fee.id, 'pending');
                                }
                              }}
                              className="p-1 px-2 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-600 hover:border-rose-200 text-xs font-semibold rounded-md transition-colors border border-slate-200 cursor-pointer"
                              title="Estornar baixa"
                            >
                              Estornar
                            </button>
                          )}

                          <button
                            onClick={() => {
                              if (confirm(`Remover lançamento de mensalidade (${fee.referenceMonth}) para ${fee.mediumName}?`)) {
                                onDeleteFee(fee.id);
                              }
                            }}
                            className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                            title="Deletar cobrança"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    Nenhuma mensalidade atende aos filtros pesquisados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bulk Generate Modal */}
      {showBulkModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-amber-100">
            <div className="bg-slate-950 p-4 text-white">
              <h4 className="font-bold text-amber-300 flex items-center gap-1.5">
                <PlusSquare className="h-5 w-5" />
                Gerar Cobranças em Lote
              </h4>
            </div>
            
            <form onSubmit={handleBulkGenerate} className="p-5 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Este utilitário criará lançamentos de mensalidades para <strong>todos os médiuns ativos</strong> na listagem para um mês específico, com suas respectivas taxas pre-cadastradas e vencimento definido para o dia 10 daquele mês.
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Selecione o Mês a Emitir
                </label>
                <input
                  type="month"
                  value={bulkMonth}
                  onChange={e => setBulkMonth(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-amber-200 rounded-lg py-2 px-3 text-sm focus:ring-2"
                  required
                />
              </div>

              <div className="bg-amber-50 p-3 rounded-lg border border-amber-100 text-[11px] text-amber-800 font-medium">
                ⚠️ Observação: Registros que já foram previamente gerados para o mesmo médium e mês de referência serão respeitados e não serão duplicados.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBulkModal(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-semibold px-3 py-2 rounded-lg cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold px-4 py-2 rounded-lg cursor-pointer"
                >
                  Gerar Lote de Cobranças
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Comprovante Review Modal */}
      {selectedFeeForReview && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-amber-100">
            <div className="bg-blue-900 p-4 text-white flex justify-between items-center bg-radial from-blue-800 to-blue-950">
              <h4 className="font-bold text-white flex items-center gap-1.5 text-sm">
                <FileText className="h-4.5 w-4.5" />
                Validar Comprovante Enviado
              </h4>
              <button
                onClick={() => setSelectedFeeForReview(null)}
                className="text-white font-bold hover:text-slate-200"
              >
                &times;
              </button>
            </div>
            
            <div className="p-5 space-y-4">
              <div className="space-y-1.5 text-sm text-slate-700">
                <p><strong>Médium:</strong> {selectedFeeForReview.mediumName}</p>
                <p><strong>Referência:</strong> {getPortgueseMonthName(selectedFeeForReview.referenceMonth)}</p>
                <p><strong>Valor:</strong> {formatCurrency(selectedFeeForReview.value)}</p>
                <p><strong>Vencimento:</strong> {selectedFeeForReview.dueDate.split('-').reverse().join('/')}</p>
              </div>

              {/* Fake Document attachment display */}
              <div className="bg-slate-50 border border-dashed border-slate-300 rounded-xl p-4 flex flex-col items-center justify-center text-center gap-2">
                <FileText className="h-10 w-10 text-blue-500" />
                <div>
                  <div className="text-xs font-semibold text-slate-700">{selectedFeeForReview.comprovanteFileName || 'comprovante_pagamento.pdf'}</div>
                  <div className="text-[10px] text-slate-400">PDF Documento • 248 KB • Transação Confirmada</div>
                </div>
                <div className="text-[10px] font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-sm font-semibold border border-emerald-200">
                  ASSINATURA DIGITAL PIX OK
                </div>
              </div>

              <div className="text-xs text-slate-500 leading-relaxed">
                O médium anexou o comprovante gerado na transação PIX. Certifique se o valor correspondente caiu na conta do Templo e clique em <strong>Aprovar</strong> para dar baixa automática na mensalidade.
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm(`Descartar este comprovante e notificar o médium?`)) {
                      // Discard proof of payment
                      onUpdateFeeStatus(selectedFeeForReview.id, 'pending');
                      setSelectedFeeForReview(null);
                    }
                  }}
                  className="bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold px-3 py-2 rounded-lg cursor-pointer"
                >
                  Rejeitar
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedFeeForReview(null)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-semibold px-3 py-2 rounded-lg cursor-pointer"
                  >
                    Voltar
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateFeeStatus(selectedFeeForReview.id, 'paid', 'pix');
                      setSelectedFeeForReview(null);
                    }}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1 shadow-sm cursor-pointer"
                  >
                    <Check className="h-3.5 w-3.5" />
                    Aprovar Pagamento
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
