/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShieldCheck, UserCheck, Lock, Eye, EyeOff, LogIn, ArrowRight, Sparkles, Star, UserPlus, Info } from 'lucide-react';
import { Medium } from '../types';
import { TupbaoLogo } from './TupbaoLogo';

interface LoginScreenProps {
  mediums: Medium[];
  onLoginAdmin: () => void;
  onLoginMedium: (mediumId: string) => void;
  onRegisterPassword: (mediumId: string, password: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  mediums,
  onLoginAdmin,
  onLoginMedium,
  onRegisterPassword
}) => {
  const [activeTab, setActiveTab] = useState<'medium' | 'admin'>('medium');
  const [regNumber, setRegNumber] = useState<string>('');
  const [mediumPassword, setMediumPassword] = useState<string>('');
  const [adminPassword, setAdminPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showMediumPassword, setShowMediumPassword] = useState<boolean>(false);
  
  // First-time setup state
  const [isFirstAccess, setIsFirstAccess] = useState<boolean>(false);
  const [firstAccessMedium, setFirstAccessMedium] = useState<Medium | null>(null);
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmNewPassword, setConfirmNewPassword] = useState<string>('');

  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [showHelperList, setShowHelperList] = useState<boolean>(false);

  const activeMediums = mediums.filter(m => m.active);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    
    // Check password
    if (adminPassword === '1234') {
      onLoginAdmin();
    } else if (adminPassword.trim() === '') {
      setErrorMsg('Por favor, informe a senha de acesso.');
    } else {
      setErrorMsg('Senha incorreta! Use a senha padrão de demonstração: 1234');
    }
  };

  const handleMediumLoginCheck = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!regNumber.trim()) {
      setErrorMsg('Por favor, informe seu Número de Cadastro.');
      return;
    }

    // Find medium
    const foundMedium = activeMediums.find(
      m => m.registrationNumber?.trim().toLowerCase() === regNumber.trim().toLowerCase()
    );

    if (!foundMedium) {
      setErrorMsg(`Número de Cadastro "${regNumber}" não encontrado no terreiro ou cadastro está desativado.`);
      return;
    }

    // If no password exists, prompt to create one
    if (!foundMedium.password) {
      setIsFirstAccess(true);
      setFirstAccessMedium(foundMedium);
      setErrorMsg('');
      return;
    }

    // If password exists, check it
    if (!mediumPassword) {
      setErrorMsg('Por favor, digite sua senha de acesso.');
      return;
    }

    if (foundMedium.password === mediumPassword) {
      onLoginMedium(foundMedium.id);
    } else {
      setErrorMsg('Senha incorreta! Certifique-se de digitar a senha cadastrada.');
    }
  };

  const handleCreatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!firstAccessMedium) return;

    if (newPassword.length < 3) {
      setErrorMsg('A senha precisa ter pelo menos 3 dígitos.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setErrorMsg('As senhas não coincidem. Digite o mesmo valor em ambos os campos.');
      return;
    }

    // Save and login
    onRegisterPassword(firstAccessMedium.id, newPassword);
    setSuccessMsg(`Senha criada com sucesso para ${firstAccessMedium.name}!`);
    
    setTimeout(() => {
      onLoginMedium(firstAccessMedium.id);
    }, 1000);
  };

  const resetFirstAccess = () => {
    setIsFirstAccess(false);
    setFirstAccessMedium(null);
    setNewPassword('');
    setConfirmNewPassword('');
    setErrorMsg('');
    setSuccessMsg('');
  };

  return (
    <div className="flex-1 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-slate-50 min-h-[75vh]">
      <div className="max-w-md w-full space-y-8">
        
        {/* Brand header */}
        <div className="text-center space-y-3">
          <div className="mx-auto w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-xl border-2 border-amber-500 hover:scale-105 transition-all">
            <TupbaoLogo className="w-22 h-22" />
          </div>
          <div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-amber-800 font-bold tracking-widest uppercase mb-1">
              <Star className="h-4 w-4 fill-amber-500 text-amber-500" />
              TUPBAO
              <Star className="h-4 w-4 fill-amber-500 text-amber-500" />
            </div>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-900">
              Controle de Mensalidades
            </h2>
            <p className="mt-2 text-sm text-slate-500">
              Gestão das Obrigações e contribuições mensais
            </p>
          </div>
        </div>

        {/* Card containing options and forms */}
        <div className="bg-white rounded-3xl border border-amber-100 shadow-xl overflow-hidden">
          
          {/* Custom Tabs */}
          {!isFirstAccess && (
            <div className="flex border-b border-slate-100 bg-slate-50/50 p-1.5">
              <button
                onClick={() => {
                  setActiveTab('medium');
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === 'medium'
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                }`}
              >
                <UserCheck className="h-4.5 w-4.5" />
                Sou Filho de Fé
              </button>
              <button
                onClick={() => {
                  setActiveTab('admin');
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === 'admin'
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                }`}
              >
                <ShieldCheck className="h-4.5 w-4.5" />
                Financeiro / Gestão
              </button>
            </div>
          )}

          <div className="p-8">
            {errorMsg && (
              <div className="mb-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-3 text-xs font-semibold flex items-center gap-2">
                ⚠️ {errorMsg}
              </div>
            )}
            
            {successMsg && (
              <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-3 text-xs font-semibold flex items-center gap-2">
                ✅ {successMsg}
              </div>
            )}

            {/* TAB: MEDIUM FIRST ACCESS / CREATE PASSWORD */}
            {isFirstAccess && firstAccessMedium && (
              <form onSubmit={handleCreatePassword} className="space-y-6">
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center space-y-1">
                  <span className="text-2xl">✨</span>
                  <h3 className="text-sm font-bold text-amber-950">Seja Bem-vindo(a), {firstAccessMedium.name}!</h3>
                  <p className="text-xs text-amber-900">
                    Sua conta foi identificada no terreiro. Como esta é a sua primeira visita ao portal, defina uma senha de acesso pessoal.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                      Crie sua Senha
                    </label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={e => setNewPassword(e.target.value)}
                      placeholder="Mínimo 3 caracteres"
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl py-3 px-4 text-sm text-slate-900 outline-none transition-all"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                      Confirme sua Senha
                    </label>
                    <input
                      type="password"
                      value={confirmNewPassword}
                      onChange={e => setConfirmNewPassword(e.target.value)}
                      placeholder="Redigite a senha criada"
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl py-3 px-4 text-sm text-slate-900 outline-none transition-all"
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={resetFirstAccess}
                    className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl text-xs transition-all cursor-pointer"
                  >
                    Voltar
                  </button>
                  <button
                    type="submit"
                    className="flex-[2] bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer"
                  >
                    <UserPlus className="h-4 w-4" />
                    Salvar e Acessar
                  </button>
                </div>
              </form>
            )}

            {/* TAB: MEDIUM LOGIN (STANDARD) */}
            {!isFirstAccess && activeTab === 'medium' && (
              <form onSubmit={handleMediumLoginCheck} className="space-y-5">
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-slate-900">Acesso do Filho de Fé</h3>
                  <p className="text-xs text-slate-400 leading-normal">
                    Informe seu número de matrícula do Templo e sua senha pessoal para acompanhar seus comprovantes, pendências e gerar Pix.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                      Número de Cadastro / Matrícula
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: 1001, 1002"
                      value={regNumber}
                      onChange={e => setRegNumber(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl py-3 px-4 text-sm text-slate-800 outline-none transition-all"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center">
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                        Sua Senha Pessoal
                      </label>
                      <span className="text-[10px] text-amber-700 font-semibold">Primeira vez? Deixe em branco e digite seu cadastro!</span>
                    </div>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                        <Lock className="h-4 w-4" />
                      </span>
                      <input
                        type={showMediumPassword ? 'text' : 'password'}
                        value={mediumPassword}
                        onChange={e => setMediumPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl py-3 pl-10 pr-10 text-sm text-slate-900 outline-none transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowMediumPassword(!showMediumPassword)}
                        className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                      >
                        {showMediumPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-950 hover:bg-slate-900 border border-slate-800 text-white font-bold py-3.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 transition-all hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                >
                  <LogIn className="h-4.5 w-4.5 text-amber-400" />
                  Acessar Painel do Filho
                  <ArrowRight className="h-4 w-4 text-slate-400" />
                </button>

                {/* Collapsible Demo Helper */}
                <div className="pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowHelperList(!showHelperList)}
                    className="w-full flex items-center justify-between text-xs text-slate-500 hover:text-amber-700 font-bold focus:outline-none cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5">
                      <Info className="h-4 w-4 text-amber-600" />
                      Precisa de ajuda? Fichas de teste de médiuns
                    </span>
                    <span>{showHelperList ? 'Recolher' : 'Visualizar'}</span>
                  </button>

                  {showHelperList && (
                    <div className="mt-2 bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2 text-[11px] text-slate-600 leading-relaxed">
                      <p className="font-semibold text-slate-700">Para simular logins de filhos de fé de demonstração:</p>
                      <ul className="space-y-1.5 list-disc pl-4 font-mono">
                        <li><strong>Mariana</strong>: Cadastro <span className="bg-slate-200 px-1 rounded font-bold">1001</span> (Senha definida: <span className="font-bold">123</span>)</li>
                        <li><strong>Carlos</strong>: Cadastro <span className="bg-slate-200 px-1 rounded font-bold">1002</span> (<em>Primeiro Acesso / Sem senha</em>)</li>
                        <li><strong>Juliana</strong>: Cadastro <span className="bg-slate-200 px-1 rounded font-bold">1003</span> (Senha definida: <span className="font-bold">123</span>)</li>
                        <li><strong>Roberto</strong>: Cadastro <span className="bg-slate-200 px-1 rounded font-bold">1004</span> (<em>Primeiro Acesso / Sem senha</em>)</li>
                        <li><strong>Ana Carolina</strong>: Cadastro <span className="bg-slate-200 px-1 rounded font-bold">1005</span> (<em>Primeiro Acesso / Sem senha</em>)</li>
                      </ul>
                      <p className="text-[10px] text-slate-400 leading-tight">Digitar qualquer código de primeiro acesso ativa a tela para criar a senha desejada na hora!</p>
                    </div>
                  )}
                </div>
              </form>
            )}

            {/* TAB: ADMIN LOGIN */}
            {!isFirstAccess && activeTab === 'admin' && (
              <form onSubmit={handleAdminLogin} className="space-y-6">
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-slate-900">Acesso Restrito à Gestão</h3>
                  <p className="text-xs text-slate-400 leading-normal">
                    Este portal é exclusivo para tesoureiros, zeladores e dirigentes responsáveis pelo controle de mensalidades em lote, livro de caixa e fluxo do Templo.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Senha de Cadastro Administrativo
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                      <Lock className="h-4 w-4" />
                    </span>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={adminPassword}
                      onChange={e => setAdminPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl py-3 pl-10 pr-10 text-sm text-slate-900 outline-none transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="bg-amber-50/50 rounded-xl p-3.5 border border-amber-200/50 flex gap-2.5 items-start">
                  <Sparkles className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-[11px] text-amber-900">
                    <strong>Ambiente Demo:</strong> Para logar na administração do terreiro, utilize a senha padrão da tesouraria: <code className="bg-amber-100 font-mono text-xs font-bold px-1.5 py-0.5 rounded text-amber-950">1234</code>.
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-950 hover:bg-slate-900 border border-slate-800 text-white font-bold py-3 px-4 rounded-xl text-sm flex items-center justify-center gap-2 transition-all hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                >
                  <Lock className="h-4.5 w-4.5 text-amber-400" />
                  Acessar Painel Central
                  <ArrowRight className="h-4 w-4 text-slate-400" />
                </button>
              </form>
            )}

          </div>
        </div>

        <p className="text-center text-[11px] text-slate-400 font-medium">
          TUPBAO • Templo de Umbanda Caboclo das Sete Encruzilhadas
        </p>
      </div>
    </div>
  );
};
