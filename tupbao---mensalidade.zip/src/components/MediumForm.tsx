/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, User, Mail, Phone, Calendar, HeartHandshake } from 'lucide-react';
import { Medium } from '../types';

interface MediumFormProps {
  medium?: Medium | null; // If editing
  nextSuggestedReg?: string; // Auto-generated default registration number code for new entries
  onSave: (data: Omit<Medium, 'id'> & { id?: string; registrationNumber?: string }) => void;
  onClose: () => void;
}

export const MediumForm: React.FC<MediumFormProps> = ({ medium, nextSuggestedReg = '', onSave, onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('Médium de Corrente');
  const [monthlyValue, setMonthlyValue] = useState(60);
  const [startDate, setStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [active, setActive] = useState(true);
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (medium) {
      setName(medium.name);
      setEmail(medium.email);
      setPhone(medium.phone);
      setRole(medium.role);
      setMonthlyValue(medium.monthlyValue);
      setStartDate(medium.startDate);
      setActive(medium.active);
      setRegistrationNumber(medium.registrationNumber || '');
    } else {
      setRegistrationNumber(nextSuggestedReg);
    }
  }, [medium, nextSuggestedReg]);

  const roles = [
    'Médium de Corrente',
    'Médium Iniciante',
    'Cambone',
    'Ogã / Atabaqueiro',
    'Dirigente Espiritual'
  ];

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    
    // Format: (XX) XXXXX-XXXX
    if (value.length > 6) {
      value = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7)}`;
    } else if (value.length > 2) {
      value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
    } else if (value.length > 0) {
      value = `(${value}`;
    }
    setPhone(value);
  };

  const validate = () => {
    const newErrors: { [key: string]: string } = {};

    if (!name.trim()) {
      newErrors.name = 'Nome completo é obrigatório';
    }
    if (!registrationNumber.trim()) {
      newErrors.registrationNumber = 'Matrícula é obrigatória';
    }
    if (!email.trim()) {
      newErrors.email = 'E-mail é obrigatório';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'E-mail inválido';
    }
    if (!phone.trim()) {
      newErrors.phone = 'Telefone para contato é obrigatório';
    }
    if (monthlyValue <= 0) {
      newErrors.monthlyValue = 'O valor deve ser maior do que zero';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onSave({
      id: medium?.id,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      role,
      monthlyValue,
      startDate,
      active,
      registrationNumber: registrationNumber.trim(),
      password: medium?.password // keep existing password if present
    });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-amber-100 transform transition-transform duration-300 scale-100">
        <div className="bg-slate-950 p-5 text-white flex justify-between items-center bg-radial from-slate-900 to-slate-950">
          <div>
            <h3 className="text-lg font-bold tracking-tight text-amber-300">
              {medium ? '✏️ Editar Cadastro do Médium' : '🌿 Cadastrar Novo Médium'}
            </h3>
            <p className="text-xs text-slate-300 mt-1">Guarde com zelo as informações dos filhos d&apos;água e da corrente</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-lg transition-colors text-slate-300 hover:text-white"
            aria-label="Fecar modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Nome */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Nome Completo do Médium
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <User className="h-4 w-4" />
                </span>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Ex: Carlos de Xangô"
                  className={`w-full bg-slate-50 border ${errors.name ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200 focus:border-amber-500 focus:ring-amber-200'} rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-800 outline-hidden transition-all focus:ring-3`}
                />
              </div>
              {errors.name && <p className="text-xs text-rose-500 mt-1">{errors.name}</p>}
            </div>

            {/* Número de Matrícula */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Nº Matrícula / Cadastro
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={registrationNumber}
                  onChange={e => setRegistrationNumber(e.target.value)}
                  placeholder="Ex: 1001"
                  className={`w-full bg-slate-50 border ${errors.registrationNumber ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200 focus:border-amber-500 focus:ring-amber-200'} rounded-xl py-2.5 px-4 text-sm text-slate-800 outline-hidden transition-all focus:ring-3`}
                />
              </div>
              {errors.registrationNumber && <p className="text-xs text-rose-500 mt-1">{errors.registrationNumber}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* E-mail */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                E-mail
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Mail className="h-4 w-4" />
                </span>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="email@exemplo.com"
                  className={`w-full bg-slate-50 border ${errors.email ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200 focus:border-amber-500 focus:ring-amber-200'} rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-800 outline-hidden transition-all focus:ring-3`}
                />
              </div>
              {errors.email && <p className="text-xs text-rose-500 mt-1">{errors.email}</p>}
            </div>

            {/* Telefone */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                WhatsApp / Telefone
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Phone className="h-4 w-4" />
                </span>
                <input
                  type="text"
                  value={phone}
                  onChange={handlePhoneChange}
                  placeholder="(11) 99999-9999"
                  className={`w-full bg-slate-50 border ${errors.phone ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200 focus:border-amber-500 focus:ring-amber-200'} rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-800 outline-hidden transition-all focus:ring-3`}
                />
              </div>
              {errors.phone && <p className="text-xs text-rose-500 mt-1">{errors.phone}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Cargo / Função */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Função Espiritual
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <HeartHandshake className="h-4 w-4" />
                </span>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-amber-200 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-800 outline-hidden focus:ring-3 transition-all appearance-none"
                >
                  {roles.map(r => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Valor da Mensalidade */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Mensalidade Contratada (R$)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm font-semibold text-slate-400">
                  R$
                </span>
                <input
                  type="number"
                  min="1"
                  step="5"
                  value={monthlyValue}
                  onChange={e => setMonthlyValue(Number(e.target.value))}
                  className={`w-full bg-slate-50 border ${errors.monthlyValue ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200 focus:border-amber-500 focus:ring-amber-200'} rounded-xl py-2.5 pl-9 pr-4 text-sm text-slate-800 outline-hidden transition-all focus:ring-3`}
                />
              </div>
              {errors.monthlyValue && <p className="text-xs text-rose-500 mt-1">{errors.monthlyValue}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Data Ingresso */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Data de Ingresso
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Calendar className="h-4 w-4" />
                </span>
                <input
                  type="date"
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-amber-200 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-800 outline-hidden focus:ring-3 transition-all"
                />
              </div>
            </div>

            {/* Status do Médium (Ativo / Inativo) */}
            <div className="flex flex-col justify-center">
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
                Status no Terreiro
              </label>
              <label className="inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={active}
                  onChange={e => setActive(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="relative w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                <span className="ms-3 text-sm font-medium text-slate-700">
                  {active ? (
                    <span className="text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-sm font-semibold text-xs">Ativo / Frequente</span>
                  ) : (
                    <span className="text-slate-500 bg-slate-100 px-2 py-0.5 rounded-sm text-xs">Afastado / Licença</span>
                  )}
                </span>
              </label>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Ao cadastrar, você poderá emitir cobranças com base no valor de R$ {monthlyValue.toFixed(2)}.</span>
          </div>

          <div className="flex space-x-3 pt-2 justify-end">
            <button
              type="button"
              onClick={onClose}
              className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold px-4 py-2.5 rounded-xl text-sm transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="bg-amber-600 hover:bg-amber-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-xs transition-colors cursor-pointer"
            >
              SalvarCadastro
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
