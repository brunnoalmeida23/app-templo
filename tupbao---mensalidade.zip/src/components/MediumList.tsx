/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, UserPlus, FileText, Check, AlertCircle, Edit, Trash2, CalendarDays, Award } from 'lucide-react';
import { Medium, MonthlyFee } from '../types';
import { UmbandistaCard } from './UmbandistaCard';

interface MediumListProps {
  mediums: Medium[];
  fees: MonthlyFee[];
  onAddMedium: () => void;
  onEditMedium: (medium: Medium) => void;
  onDeleteMedium: (id: string) => void;
  onIssueFee: (mediumId: string, referenceMonth: string, value: number, dueDate: string) => void;
}

export const MediumList: React.FC<MediumListProps> = ({
  mediums,
  fees,
  onAddMedium,
  onEditMedium,
  onDeleteMedium,
  onIssueFee
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [roleFilter, setRoleFilter] = useState('all');
  const [issuingMediumId, setIssuingMediumId] = useState<string | null>(null);
  const [selectedCardMedium, setSelectedCardMedium] = useState<Medium | null>(null);
  
  // Issuing fee form inputs
  const [refMonth, setRefMonth] = useState('2026-06');
  const [customValue, setCustomValue] = useState<number>(60);
  const [dueDate, setDueDate] = useState('2026-06-10');

  const roles = Array.from(new Set(mediums.map(m => m.role)));

  const handleOpenIssueModal = (medium: Medium) => {
    setIssuingMediumId(medium.id);
    setCustomValue(medium.monthlyValue);
    
    // Set standard due date for selected month (the 10th of reference month)
    setRefMonth('2026-06');
    setDueDate('2026-06-10');
  };

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!issuingMediumId) return;

    onIssueFee(issuingMediumId, refMonth, customValue, dueDate);
    setIssuingMediumId(null);
  };

  const handleMonthChange = (monthStr: string) => {
    setRefMonth(monthStr);
    // Automatically set due date to the 10th of that month
    setDueDate(`${monthStr}-10`);
  };

  // Filter mediums list
  const filteredMediums = mediums.filter(medium => {
    const matchesSearch = medium.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          medium.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          medium.phone.includes(searchTerm);
    
    const matchesStatus = statusFilter === 'all' ? true :
                         statusFilter === 'active' ? medium.active === true : 
                         medium.active === false;

    const matchesRole = roleFilter === 'all' ? true : medium.role === roleFilter;

    return matchesSearch && matchesStatus && matchesRole;
  });

  const getMediumPendingFeesCount = (mediumId: string) => {
    return fees.filter(f => f.mediumId === mediumId && f.status !== 'paid').length;
  };

  const getMediumTotalContrib = (mediumId: string) => {
    return fees.filter(f => f.mediumId === mediumId && f.status === 'paid').reduce((sum, f) => sum + f.value, 0);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      {/* Search & Action Panel */}
      <div className="bg-white rounded-xl p-4 border border-amber-100 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 flex-1">
          {/* Search bar */}
          <div className="relative flex-1">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search className="h-4 w-4" />
            </span>
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Buscar por nome, e-mail ou telefone..."
              className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-amber-200 rounded-lg py-2.5 pl-10 pr-4 text-sm text-slate-800 outline-hidden transition-all focus:ring-2"
            />
          </div>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-lg text-sm px-3 py-2.5 text-slate-700 outline-hidden focus:ring-2 focus:ring-amber-200"
          >
            <option value="all">Filtro: Todos Status</option>
            <option value="active">Apenas Ativos</option>
            <option value="inactive">Apenas Licenciados</option>
          </select>

          {/* Role filter */}
          <select
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-lg text-sm px-3 py-2.5 text-slate-700 outline-hidden focus:ring-2 focus:ring-amber-200"
          >
            <option value="all">Filtro: Todas Funções</option>
            {roles.map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        </div>

        <button
          onClick={onAddMedium}
          className="bg-amber-600 hover:bg-amber-700 text-white text-sm font-semibold px-4 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <UserPlus className="h-4.5 w-4.5" />
          CadastrarMédium
        </button>
      </div>

      {/* Grid listing */}
      <div className="bg-white rounded-xl border border-amber-100 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 uppercase text-xs font-bold border-b border-amber-100/60">
                <th className="py-4 px-6">Nome do Médium / Função</th>
                <th className="py-4 px-6">Contato</th>
                <th className="py-4 px-6 text-center">Início</th>
                <th className="py-4 px-6 text-center">Taxa Mensal</th>
                <th className="py-4 px-6 text-center">Inadimplências</th>
                <th className="py-4 px-6 text-center">Total Pago</th>
                <th className="py-4 px-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-700">
              {filteredMediums.length > 0 ? (
                filteredMediums.map(medium => {
                  const pendingCount = getMediumPendingFeesCount(medium.id);
                  const totalPaid = getMediumTotalContrib(medium.id);

                  return (
                    <tr key={medium.id} className="hover:bg-amber-50/20 transition-colors">
                      <td className="py-4 px-6">
                        <div className="font-semibold text-slate-800">{medium.name}</div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-sm">
                            {medium.role}
                          </span>
                          {medium.active ? (
                            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-1 py-0.5 rounded-sm font-medium">Ativo</span>
                          ) : (
                            <span className="text-[10px] text-slate-400 bg-slate-100 px-1 py-0.5 rounded-sm font-medium">Licenciado</span>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="text-xs font-mono">{medium.phone}</div>
                        <div className="text-xs text-slate-400 truncate max-w-[180px]">{medium.email}</div>
                      </td>
                      <td className="py-4 px-6 text-center text-xs font-mono">
                        {medium.startDate.split('-').reverse().join('/')}
                      </td>
                      <td className="py-4 px-6 text-center font-semibold text-slate-600 font-mono">
                        {formatCurrency(medium.monthlyValue)}
                      </td>
                      <td className="py-4 px-6 text-center">
                        {pendingCount > 0 ? (
                          <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 font-bold px-2 py-0.5 rounded-sm text-xs">
                            <AlertCircle className="h-3 w-3" />
                            {pendingCount} pendente{pendingCount > 1 ? 's' : ''}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-sm text-xs">
                            <Check className="h-3 w-3" />
                            Em dia
                          </span>
                        )}
                      </td>
                      <td className="py-4 px-6 text-center font-bold text-slate-800 font-mono">
                        {formatCurrency(totalPaid)}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedCardMedium(medium)}
                            className="p-1 px-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-md flex items-center gap-1 transition-colors shadow-xs hover:scale-102 cursor-pointer"
                            title="Visualizar Carteirinha de Umbandista"
                          >
                            <Award className="h-3.5 w-3.5" />
                            Carteirinha
                          </button>
                          <button
                            onClick={() => handleOpenIssueModal(medium)}
                            className="p-1 px-2.5 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold rounded-md flex items-center gap-1 transition-colors border border-amber-200/50 cursor-pointer"
                            title="Emitir cobrança manual de mensalidade"
                          >
                            <FileText className="h-3.5 w-3.5" />
                            Cobrar
                          </button>
                          <button
                            onClick={() => onEditMedium(medium)}
                            className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-slate-700 rounded-md transition-colors cursor-pointer"
                            title="Editar cadastro"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Tem certeza que dejesa remover o cadastro de ${medium.name}? Todas as mensalidades associadas serão mantidas.`)) {
                                onDeleteMedium(medium.id);
                              }
                            }}
                            className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                            title="Remover cadastro"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    Nenhum médium atende aos filtros pesquisados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Issuing Fee Modal */}
      {issuingMediumId && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-amber-100">
            <div className="bg-slate-900 p-4 text-white flex justify-between items-center">
              <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                <CalendarDays className="h-4 w-4" />
                Emitir Mensalidade Avulsa
              </h4>
              <button
                onClick={() => setIssuingMediumId(null)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>
            
            <form onSubmit={handleIssueSubmit} className="p-5 space-y-4">
              <p className="text-xs text-slate-500">
                Você está gerando um lançamento financeiro para o médium <strong>{mediums.find(m => m.id === issuingMediumId)?.name}</strong>.
              </p>

              {/* Reference Month */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Mês de Referência
                </label>
                <input
                  type="month"
                  value={refMonth}
                  onChange={e => handleMonthChange(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-amber-200 rounded-lg py-2 px-3 text-sm"
                  required
                />
              </div>

              {/* Value */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Valor (R$)
                </label>
                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={customValue}
                  onChange={e => setCustomValue(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-amber-200 rounded-lg py-2 px-3 text-sm font-mono"
                  required
                />
              </div>

              {/* Due Date */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Data de Vencimento
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={e => setDueDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-amber-200 rounded-lg py-2 px-3 text-sm"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIssuingMediumId(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-semibold px-3 py-2 rounded-lg cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold px-4 py-2 rounded-lg cursor-pointer"
                >
                  Emitir Cobrança
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Membership Card Modal */}
      {selectedCardMedium && (
        <UmbandistaCard 
          medium={selectedCardMedium} 
          onClose={() => setSelectedCardMedium(null)} 
        />
      )}
    </div>
  );
};
