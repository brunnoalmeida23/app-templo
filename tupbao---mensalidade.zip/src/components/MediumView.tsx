/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Search, LogIn, LogOut, CheckCircle, Clock, AlertTriangle, Copy, Check, FileCheck, QrCode, UploadCloud, Smartphone, ArrowRight, Printer, Star, Award } from 'lucide-react';
import { Medium, MonthlyFee } from '../types';
import { getPortgueseMonthName, getPixEMVCode } from '../data';
import { UmbandistaCard } from './UmbandistaCard';
import { TupbaoLogo } from './TupbaoLogo';

interface MediumViewProps {
  mediums: Medium[];
  fees: MonthlyFee[];
  onUploadComprovante: (feeId: string, fileName: string) => void;
  onSimulateInstantPay: (feeId: string) => void;
  initialMediumId?: string | null;
  isPreLoggedIn?: boolean;
  onLogout?: () => void;
}

export const MediumView: React.FC<MediumViewProps> = ({
  mediums,
  fees,
  onUploadComprovante,
  onSimulateInstantPay,
  initialMediumId = null,
  isPreLoggedIn = false,
  onLogout
}) => {
  // Simulator login state
  const [selectedMediumId, setSelectedMediumId] = useState<string | null>(initialMediumId);
  const [isLoggedIn, setIsLoggedIn] = useState(isPreLoggedIn);

  // Sync state if props change
  useEffect(() => {
    if (initialMediumId !== null) {
      setSelectedMediumId(initialMediumId);
    }
    setIsLoggedIn(isPreLoggedIn);
  }, [initialMediumId, isPreLoggedIn]);
  const [paymentFee, setPaymentFee] = useState<MonthlyFee | null>(null);
  const [copiedText, setCopiedText] = useState(false);
  const [uploadingFeeId, setUploadingFeeId] = useState<string | null>(null);

  // Receipt Modal
  const [receiptFee, setReceiptFee] = useState<MonthlyFee | null>(null);
  const [showCarteirinha, setShowCarteirinha] = useState(false);

  const activeMediums = mediums.filter(m => m.active);
  const currentMedium = mediums.find(m => m.id === selectedMediumId);
  const mediumFees = fees.filter(f => f.mediumId === selectedMediumId).sort((a,b) => b.referenceMonth.localeCompare(a.referenceMonth));

  const handleCopyPix = (pixCode: string) => {
    navigator.clipboard.writeText(pixCode);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
  };

  const handleSimulatePayment = (feeId: string) => {
    onSimulateInstantPay(feeId);
    setPaymentFee(null);
  };

  const handleSimulateUpload = (feeId: string) => {
    const defaultFiles = [
      'comprovante_pix_banco_itau.pdf',
      'comprovante_bb_mensalidade.pdf',
      'foto_recibo_transacao_nubank.png'
    ];
    const randomFile = defaultFiles[Math.floor(Math.random() * defaultFiles.length)];
    onUploadComprovante(feeId, randomFile);
    setUploadingFeeId(null);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      {/* Login / Identity Selector Sim */}
      {!isLoggedIn ? (
        <div className="bg-white rounded-2xl border border-amber-100 max-w-lg mx-auto overflow-hidden shadow-xs">
          <div className="bg-slate-950 p-6 text-white text-center bg-radial from-slate-900 to-slate-950">
            <div className="mx-auto w-14 h-14 bg-white rounded-full flex items-center justify-center mb-3 shadow-md">
              <TupbaoLogo className="w-13 h-13" />
            </div>
            <h3 className="text-xl font-bold tracking-tight text-amber-300">Portal do Médium</h3>
            <p className="text-xs text-slate-300 mt-1">Selecione seu nome para gerenciar suas mensalidades e obter comprovantes</p>
          </div>

          <div className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Selecione seu nome da lista de Médiuns
              </label>
              <select
                value={selectedMediumId || ''}
                onChange={e => setSelectedMediumId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-xl py-3 px-4 text-sm text-slate-800 outline-hidden"
              >
                <option value="">-- Escolha seu cadastro --</option>
                {activeMediums.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.role})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => {
                if (selectedMediumId) setIsLoggedIn(true);
              }}
              disabled={!selectedMediumId}
              className={`w-full font-semibold py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                selectedMediumId 
                  ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-md' 
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <LogIn className="h-4.5 w-4.5" />
              Entrar no Portal
            </button>

            <p className="text-[10px] text-center text-slate-400">
              * Ambiente simulado para facilitar testes e demonstrações de fluxo de caixa da corrente.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Welcome profile banner */}
          <div className="bg-white rounded-xl p-5 border border-amber-100 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-2xl border border-amber-200 shadow-xs">
                🌿
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800 tracking-tight">{currentMedium?.name}</h3>
                <div className="flex flex-wrap items-center gap-2 mt-1">
                  <span className="text-xs text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-sm font-semibold">
                    {currentMedium?.role}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    Ingresso: {currentMedium?.startDate.split('-').reverse().join('/')}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              <div className="bg-slate-50 border border-slate-100 rounded-xl px-4 py-2 text-right hidden sm:block">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Mensalidade Fixa</div>
                <div className="text-base font-bold text-slate-800 font-mono">{formatCurrency(currentMedium?.monthlyValue || 0)}</div>
              </div>
              <button
                onClick={() => setShowCarteirinha(true)}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-3 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer w-full justify-center sm:w-auto shadow-sm"
              >
                <Award className="h-4 w-4" />
                Minha Carteirinha
              </button>
              <button
                onClick={() => {
                  setIsLoggedIn(false);
                  if (onLogout) onLogout();
                }}
                className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold px-3 py-2 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer w-full justify-center sm:w-auto"
              >
                <LogOut className="h-4 w-4" />
                Sair do Portal
              </button>
            </div>
          </div>

          {/* Monthly fees records */}
          <div className="bg-white rounded-xl border border-amber-100 overflow-hidden shadow-xs">
            <div className="bg-slate-900 border-b border-amber-100/30 p-4 flex justify-between items-center text-white">
              <h4 className="font-semibold text-amber-300 text-sm flex items-center gap-2">
                📂 Minhas Mensalidades
              </h4>
              <p className="text-xs text-slate-400">Clique para pagar ou emitir comprovantes</p>
            </div>

            <div className="divide-y divide-slate-100">
              {mediumFees.length > 0 ? (
                mediumFees.map(fee => (
                  <div key={fee.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                    {/* Month and status */}
                    <div className="flex items-start gap-4">
                      <div className="pt-1">
                        {fee.status === 'paid' ? (
                          <div className="p-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg">
                            <CheckCircle className="h-5 w-5" />
                          </div>
                        ) : fee.status === 'overdue' ? (
                          <div className="p-2 bg-rose-50 text-rose-800 border border-rose-200 rounded-lg">
                            <AlertTriangle className="h-5 w-5" />
                          </div>
                        ) : (
                          <div className="p-2 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg">
                            <Clock className="h-5 w-5" />
                          </div>
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-slate-800 text-base flex items-center gap-1.5 flex-wrap">
                          {fee.isEventFee ? (
                            <>
                              <span className="text-amber-800 bg-amber-50 border border-amber-200 text-[10px] font-extrabold py-0.5 px-2 rounded-full uppercase tracking-wider">Taxa Extra</span>
                              <span className="text-slate-900">{fee.eventName}</span>
                            </>
                          ) : (
                            <span>Mensalidade de {getPortgueseMonthName(fee.referenceMonth)}</span>
                          )}
                        </div>
                        <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs">
                          <span className="font-bold text-slate-600 font-mono">
                            Valor: {formatCurrency(fee.value)}
                          </span>
                          <span className="text-slate-400">•</span>
                          <span className="text-slate-500 font-mono">
                            Vencimento: {fee.dueDate.split('-').reverse().join('/')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Transaction interactions */}
                    <div className="flex flex-wrap sm:items-center justify-start sm:justify-end gap-3">
                      {fee.status === 'paid' ? (
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-1 rounded-sm border border-emerald-200 font-semibold font-mono text-center">
                            Pago em {fee.paymentDate?.split('-').reverse().join('/')} ({fee.paymentMethod?.toUpperCase()})
                          </span>
                          <button
                            onClick={() => setReceiptFee(fee)}
                            className="bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <Printer className="h-3.5 w-3.5" />
                            Recibo
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 flex-1 sm:flex-initial justify-between sm:justify-start w-full sm:w-auto">
                          {fee.comprovanteUploaded ? (
                            <span className="text-xs text-blue-700 bg-blue-50 border border-blue-200/50 rounded-lg p-2 flex items-center gap-1.5">
                              <FileCheck className="h-4 w-4" />
                              Comprovante enviado! Aguarde tesoureiro.
                            </span>
                          ) : (
                            <div className="flex gap-2 w-full sm:w-auto">
                              <button
                                onClick={() => setUploadingFeeId(fee.id)}
                                className="bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 text-xs font-semibold px-3 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-colors flex-1 sm:flex-initial cursor-pointer"
                              >
                                <UploadCloud className="h-4 w-4" />
                                Anexar Comprovante
                              </button>
                              <button
                                onClick={() => setPaymentFee(fee)}
                                className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center justify-center gap-1.5 shadow-sm transition-colors flex-1 sm:flex-initial cursor-pointer animate-pulse"
                              >
                                <Smartphone className="h-4 w-4" />
                                Pagar com PIX
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-slate-400">
                  Nenhuma mensalidade emitida ainda para sua conta. Entre em contato com a administração do Templo.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* PIX Payment Modal Sim */}
      {paymentFee && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-amber-100">
            <div className="bg-slate-950 p-4 text-white flex justify-between items-center">
              <h4 className="font-bold text-amber-300 flex items-center gap-1.5">
                <QrCode className="h-5 w-5" />
                Pagar com PIX Copia e Cola
              </h4>
              <button onClick={() => setPaymentFee(null)} className="text-white hover:text-amber-300 font-bold">
                &times;
              </button>
            </div>

            <div className="p-5 space-y-4 text-center">
              <div className="space-y-1">
                <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">Referência</div>
                <div className="font-bold text-slate-800 text-lg">{getPortgueseMonthName(paymentFee.referenceMonth)}</div>
                <div className="font-mono text-2xl font-bold text-emerald-600">{formatCurrency(paymentFee.value)}</div>
              </div>

              {/* Simulated QR Code SVG */}
              <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-100 inline-block">
                <svg className="w-40 h-40 mx-auto" viewBox="0 0 100 100" fill="currentColor">
                  {/* Outer border of QR */}
                  <rect x="5" y="5" width="25" height="25" fill="#1e293b" />
                  <rect x="10" y="10" width="15" height="15" fill="#ffffff" />
                  <rect x="13" y="13" width="9" height="9" fill="#1e293b" />

                  <rect x="70" y="5" width="25" height="25" fill="#1e293b" />
                  <rect x="75" y="10" width="15" height="15" fill="#ffffff" />
                  <rect x="78" y="13" width="9" height="9" fill="#1e293b" />

                  <rect x="5" y="70" width="25" height="25" fill="#1e293b" />
                  <rect x="10" y="75" width="15" height="15" fill="#ffffff" />
                  <rect x="13" y="78" width="9" height="9" fill="#1e293b" />

                  {/* Scrambled dots */}
                  <rect x="35" y="10" width="10" height="5" fill="#1e293b" />
                  <rect x="50" y="5" width="5" height="15" fill="#1e293b" />
                  <rect x="60" y="20" width="5" height="5" fill="#1e293b" />
                  <rect x="40" y="25" width="15" height="5" fill="#1e293b" />

                  <rect x="5" y="35" width="15" height="5" fill="#1e293b" />
                  <rect x="25" y="40" width="5" height="15" fill="#1e293b" />
                  <rect x="10" y="50" width="10" height="5" fill="#1e293b" />

                  <rect x="35" y="35" width="30" height="30" fill="#1e293b" />
                  <rect x="40" y="40" width="20" height="20" fill="#ffffff" />
                  <rect x="45" y="45" width="10" height="10" fill="#1e293b" />

                  <rect x="70" y="35" width="5" height="15" fill="#1e293b" />
                  <rect x="80" y="45" width="15" height="10" fill="#1e293b" />
                  <rect x="75" y="60" width="20" height="5" fill="#1e293b" />

                  <rect x="35" y="70" width="10" height="10" fill="#1e293b" />
                  <rect x="50" y="80" width="25" height="10" fill="#1e293b" />
                  <rect x="80" y="75" width="15" height="15" fill="#1e293b" />
                  <rect x="40" y="90" width="10" height="5" fill="#1e293b" />
                </svg>
                <div className="text-[10px] text-slate-400 mt-2 font-semibold">Chave: templo@pix.org</div>
              </div>

              {/* Copia e Cola String Box */}
              <div>
                <div className="text-xs font-semibold text-slate-500 mb-1.5 text-left">Código PIX Copia e Cola</div>
                <div className="flex gap-2">
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-2 text-[10px] font-mono text-slate-600 truncate flex-1 text-left select-all">
                    {getPixEMVCode(currentMedium?.name || '', paymentFee.referenceMonth, paymentFee.value)}
                  </div>
                  <button
                    onClick={() => handleCopyPix(getPixEMVCode(currentMedium?.name || '', paymentFee.referenceMonth, paymentFee.value))}
                    className="bg-amber-100 hover:bg-amber-200 border border-amber-200 text-amber-800 rounded-lg px-2.5 flex items-center justify-center transition-colors cursor-pointer"
                    title="Copiar código PIX"
                  >
                    {copiedText ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                  </button>
                </div>
                {copiedText && <p className="text-[11px] text-emerald-600 font-semibold mt-1 text-left">Código copiado para a área de transferência!</p>}
              </div>

              {/* Fast simulator actions */}
              <div className="bg-slate-100 p-3 rounded-xl border border-slate-200/50 text-left space-y-2">
                <div className="text-[10px] text-slate-500 uppercase font-bold">Simulador de Transações</div>
                <div className="flex flex-col gap-2">
                  {/* Fast Instant payment confiramtion simulation */}
                  <button
                    type="button"
                    onClick={() => handleSimulatePayment(paymentFee.id)}
                    className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <CheckCircle className="h-4 w-4" />
                    Simular Pagamento Instantâneo
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setPaymentFee(null)}
                className="text-xs text-slate-500 hover:text-slate-800 font-medium"
              >
                Voltar mais tarde
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Attach Proof / Comprovante Upload Modal */}
      {uploadingFeeId && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-amber-100">
            <div className="bg-slate-950 p-4 text-white flex justify-between items-center">
              <h4 className="font-bold text-amber-300 flex items-center gap-1.5">
                <UploadCloud className="h-5 w-5" />
                Anexar Comprovante
              </h4>
              <button onClick={() => setUploadingFeeId(null)} className="text-white hover:text-amber-300 font-bold">
                &times;
              </button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Você pode anexar um comprovante de transferência bancária ou cópia do PIX feito para que o financeiro do terreiro confirme o recebimento e lhe emita a baixa.
              </p>

              {/* Drag & Drop simulated area */}
              <div
                onClick={() => handleSimulateUpload(uploadingFeeId)}
                className="border-2 border-dashed border-slate-300 hover:border-amber-500 bg-slate-50 hover:bg-slate-50/20 rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2 group"
              >
                <div className="p-3 bg-amber-100 text-amber-800 rounded-lg group-hover:scale-105 transition-transform">
                  <UploadCloud className="h-6 w-6" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-700">Clique para selecionar imagem/PDF</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">Formatos suportados: PNG, JPG, PDF (Máx 5MB)</div>
                </div>
              </div>

              <div className="text-[10px] text-center text-slate-400">
                * Clicando na área pontilhada simula a seleção do arquivo e o anexa para validação da tesouraria.
              </div>

              <div className="flex justify-end gap-2 text-xs pt-1">
                <button
                  type="button"
                  onClick={() => setUploadingFeeId(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-500 font-semibold px-3 py-1.5 rounded-lg cursor-pointer"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Simulated Receipt (Recibo de Pagamento) print look details */}
      {receiptFee && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-amber-100">
            {/* Immersive Receipt Canvas */}
            <div id="receipt-print-zone" className="p-8 bg-amber-50/30 font-sans relative">
              {/* Sacred watermarks simulation aesthetics */}
              <div className="absolute inset-0 bg-radial from-transparent to-amber-200/5 pointer-events-none -z-10" />
              
              <div className="text-center pb-6 border-b border-dashed border-slate-300">
                <div className="flex items-center justify-center gap-1 text-xs text-amber-800 font-bold tracking-widest uppercase mb-1">
                  <Star className="h-4 w-4 fill-amber-500 text-amber-500" />
                  Templo de Umbanda Caboclo das Sete Encruzilhadas
                  <Star className="h-4 w-4 fill-amber-500 text-amber-500" />
                </div>
                <h4 className="text-xl font-bold tracking-tight text-slate-900">RECIBO DE QUITAÇÃO</h4>
                <p className="text-[10px] text-slate-400 font-mono mt-0.5">CNPJ: 00.322.281/0001-90 | REGISTRO DE FILIAÇÃO</p>
              </div>

              <div className="py-6 space-y-4 text-slate-700 text-sm leading-relaxed">
                <div>
                  Recebemos de <strong>{currentMedium?.name}</strong>, inscrito como <em>{currentMedium?.role}</em> deste templo, a quantia líquida de:
                </div>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center font-bold text-lg font-mono text-emerald-800">
                  {formatCurrency(receiptFee.value)} (* {receiptFee.value === 50 ? 'Cinquenta reais' : receiptFee.value === 60 ? 'Sessenta reais' : receiptFee.value === 80 ? 'Oitenta reais' : 'Valor estipulado'} *)
                </div>

                <div>
                  No dia <strong>{receiptFee.paymentDate?.split('-').reverse().join('/')}</strong>, referente {receiptFee.isEventFee ? (
                    <>ao rateio do evento <strong>"{receiptFee.eventName}"</strong></>
                  ) : (
                    <>à contribuição financeira mensal de <strong>{getPortgueseMonthName(receiptFee.referenceMonth)}</strong></>
                  )}, descarregando por meio deste recibo digital toda obrigação financeira estipulada para o ciclo.
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4 text-xs font-mono text-slate-400">
                  <div>
                    <div><strong>FORMA DE PAGAMENTO:</strong></div>
                    <div className="uppercase text-slate-600 font-semibold">{receiptFee.paymentMethod || 'PIX'}</div>
                  </div>
                  <div>
                    <div><strong>ID DE TRANSAÇÃO:</strong></div>
                    <div className="text-slate-600 font-semibold">T-{receiptFee.id.toUpperCase()}</div>
                  </div>
                </div>
              </div>

              <div className="text-center pt-8 border-t border-dashed border-slate-300">
                <div className="max-w-[200px] mx-auto border-b border-slate-400 pb-1 font-semibold text-slate-800 text-xs">
                  Tesouraria Geral do Templo
                </div>
                <p className="text-[10px] text-slate-400 font-mono mt-1">Este documento é emitido pelo sistema interno e possui autenticidade garantida.</p>
              </div>
            </div>

            {/* Action options */}
            <div className="bg-slate-950 p-4 flex justify-between items-center">
              <button
                onClick={() => setReceiptFee(null)}
                className="text-slate-400 hover:text-white text-xs font-bold px-3 py-1.5 cursor-pointer"
              >
                Fechar Recibo
              </button>
              
              <button
                onClick={() => {
                  window.print();
                }}
                className="bg-amber-500 hover:bg-amber-600 text-slate-900 text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Printer className="h-4 w-4" />
                Imprimir Recibo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Membership Card Modal */}
      {showCarteirinha && currentMedium && (
        <UmbandistaCard 
          medium={currentMedium} 
          onClose={() => setShowCarteirinha(false)} 
        />
      )}
    </div>
  );
};
