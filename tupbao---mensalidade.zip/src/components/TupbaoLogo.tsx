/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface TupbaoLogoProps {
  className?: string;
  size?: number;
}

export const TupbaoLogo: React.FC<TupbaoLogoProps> = ({ className = '', size }) => {
  const inlineStyle = size ? { width: size, height: size } : undefined;

  return (
    <svg
      viewBox="0 0 500 500"
      className={`select-none shrink-0 ${className}`}
      style={inlineStyle}
      referrerPolicy="no-referrer"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Outer black boundary */}
      <circle cx="250" cy="250" r="240" fill="#f5a623" stroke="#000000" strokeWidth="4" />

      {/* Inner white circle */}
      <circle cx="250" cy="250" r="175" fill="#ffffff" stroke="#000000" strokeWidth="4" />

      {/* Hidden Text Path for curved text */}
      {/* A clockwise path from bottom-left (approx 132 deg) to bottom-right (approx 48 deg), radius 208 */}
      <path
        id="circleLogoTextPath"
        d="M 95,389.2 A 208,208 0 1,1 405,389.2"
        fill="none"
        stroke="none"
      />

      {/* Curved Text - "TEMPLO DE UMBANDA PAI BENEDITO DAS ALMAS E OBALUAÊ" */}
      <text
        fill="#000000"
        fontSize="24.5"
        fontWeight="bold"
        fontFamily="system-ui, -apple-system, sans-serif"
        letterSpacing="2.2"
      >
        <textPath
          href="#circleLogoTextPath"
          startOffset="50%"
          textAnchor="middle"
        >
          TEMPLO DE UMBANDA PAI BENEDITO DAS ALMAS E OBALUAÊ
        </textPath>
      </text>

      {/* Stylized "TUPBAO" letters */}
      <g>
        {/* T-like stylized cross letter (x: 95 -> 143) */}
        <g>
          {/* Top horizontal stem */}
          <rect x="95" y="195" width="48" height="8.5" rx="1.5" fill="#000000" />
          {/* Serif hooks on ends of top bar */}
          <rect x="95" y="195" width="7" height="15" rx="1" fill="#000000" />
          <rect x="136" y="195" width="7" height="15" rx="1" fill="#000000" />
          {/* Vertical central stem */}
          <rect x="115" y="195" width="8.5" height="50" rx="1.5" fill="#000000" />
          {/* Middle cross bar */}
          <rect x="101" y="215" width="36.5" height="8.5" rx="1.5" fill="#000000" />
        </g>

        {/* U - Sans Serif Bold (x: 153 -> 195) */}
        <text
          x="151"
          y="245"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="56"
          fill="#000000"
        >
          U
        </text>

        {/* P - Sans Serif Bold (x: 204 -> 245) */}
        <text
          x="202"
          y="245"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="56"
          fill="#000000"
        >
          P
        </text>

        {/* B - Sans Serif Bold (x: 254 -> 295) */}
        <text
          x="251"
          y="245"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="56"
          fill="#000000"
        >
          B
        </text>

        {/* A - Equilateral Triangle / Delta (x: 304 -> 348) */}
        <g>
          <polygon points="304,245 326,195 348,245" fill="#000000" />
          {/* Inner negative space triangle */}
          <polygon points="314,240 326,211 338,240" fill="#ffffff" />
        </g>

        {/* O - Target dotted circle (x: 356 -> 400) */}
        <g>
          <circle cx="378" cy="221" r="22" fill="#000000" />
          <circle cx="378" cy="221" r="14" fill="#ffffff" />
          <circle cx="378" cy="221" r="5" fill="#000000" />
        </g>
      </g>

      {/* Solid Black Latin Cross */}
      <g>
        {/* Vertical beam */}
        <rect x="242" y="305" width="16" height="104" rx="2" fill="#000000" />
        {/* Horizontal beam */}
        <rect x="210" y="331" width="80" height="16" rx="2" fill="#000000" />
      </g>
    </svg>
  );
};
