/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Printer, X, Award, Shield, User, Calendar, Hash, FileText, Check, Star, RefreshCw } from 'lucide-react';
import { Medium } from '../types';
import { TupbaoLogo } from './TupbaoLogo';

interface UmbandistaCardProps {
  medium: Medium;
  onClose: () => void;
}

export const UmbandistaCard: React.FC<UmbandistaCardProps> = ({ medium, onClose }) => {
  const [selectedSymbol, setSelectedSymbol] = useState<'🕊️' | '🌿' | '🏹' | '⚔️' | '⚓' | '🔱'>('🕊️');
  const symbols = [
    { label: 'Paz (Oxalá)', char: '🕊️' },
    { label: 'Ervas (Ossaim/Mata)', char: '🌿' },
    { label: 'Caboclo (Oxóssi)', char: '🏹' },
    { label: 'Guerreiro (Ogum)', char: '⚔️' },
    { label: 'Marinheiro (Iemanjá)', char: '⚓' },
    { label: 'Protetor (Exu/Lopo)', char: '🔱' },
  ] as const;

  const rawDate = new Date(medium.startDate + 'T12:00:00');
  const formattedDate = !isNaN(rawDate.getTime()) 
    ? rawDate.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })
    : medium.startDate.split('-').reverse().join('/');

  return (
    <div className="fixed inset-0 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 md:p-8 border border-amber-100 shadow-2xl space-y-6 relative animate-fade-in my-8 print:my-0 print:p-0 print:shadow-none print:border-0 print:bg-white">
        
        {/* Modal Close Button - hidden during print */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 bg-slate-100 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-full transition-colors cursor-pointer print:hidden"
          title="Fechar"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header - hidden during print */}
        <div className="border-b border-slate-100 pb-4 pr-10 print:hidden">
          <div className="flex items-center gap-2 text-amber-600">
            <Award className="h-5 w-5 text-amber-600 font-bold" />
            <span className="text-xs uppercase font-extrabold tracking-widest">Credencial do Terreiro</span>
          </div>
          <h3 className="text-xl font-black text-slate-900">Carteirinha de Umbandista</h3>
          <p className="text-xs text-slate-500 mt-1">
            Esta é a credencial oficial do filho de fé na casa. Você pode personalizar o selo espiritual e imprimir em tamanho oficial.
          </p>
        </div>

        {/* Symbol Selector Panel - hidden during print */}
        <div className="bg-amber-50/50 rounded-2xl p-4 border border-amber-100/50 space-y-2 print:hidden">
          <label className="block text-[11px] font-bold text-amber-900 uppercase tracking-wider">
            Selecione o Selo de Falange para a Carteirinha:
          </label>
          <div className="flex flex-wrap gap-2">
            {symbols.map(sym => (
              <button
                key={sym.char}
                onClick={() => setSelectedSymbol(sym.char)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
                  selectedSymbol === sym.char
                    ? 'bg-amber-600 text-white border-amber-600 shadow-xs scale-102 font-bold'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                }`}
              >
                <span className="text-sm">{sym.char}</span>
                <span>{sym.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Printable Credentials Grid */}
        <div className="flex flex-col md:flex-row gap-6 justify-center items-center py-4 print:p-0 print:gap-10">
          
          {/* FRONT (FRENTE) */}
          <div className="relative w-[340px] h-[216px] bg-sky-950 rounded-2xl overflow-hidden shadow-lg border border-sky-900/40 text-white flex flex-col justify-between p-4 bg-radial from-slate-900 to-slate-950 shrink-0 print:shadow-none print:border-slate-300">
            {/* Ambient watermarks */}
            <div className="absolute top-0 right-0 w-28 h-28 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
            
            {/* Header / Casa Logo */}
            <div className="flex items-center gap-2.5 border-b border-slate-800/60 pb-2">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-inner">
                <TupbaoLogo className="w-9 h-9" />
              </div>
              <div>
                <h4 className="text-[10px] font-black tracking-widest text-amber-400 uppercase leading-tight font-sans">
                  TEMPLO DE UMBANDA
                </h4>
                <p className="text-[9px] font-bold text-slate-300 uppercase tracking-wider leading-none">
                  Pai Benedito das Almas e Obaluaê
                </p>
              </div>
            </div>

            {/* Middle body info */}
            <div className="flex gap-3 my-2 items-center">
              {/* Profile image space */}
              <div className="w-16 h-20 bg-slate-800/80 rounded-lg border border-slate-700/60 flex flex-col items-center justify-center relative overflow-hidden self-center">
                <User className="h-7 w-7 text-slate-500" />
                <span className="text-[7.5px] text-slate-400 mt-1 font-bold uppercase tracking-widest leading-none">FOTO 3X4</span>
                <div className="absolute bottom-0 inset-x-0 py-0.5 bg-slate-900/90 text-center text-[7px] text-amber-400 font-extrabold uppercase tracking-wide">
                  TUPBAO
                </div>
              </div>

              {/* Personal data */}
              <div className="flex-1 space-y-1.5">
                <div>
                  <span className="block text-[7px] text-slate-400 uppercase tracking-widest font-bold font-sans">Nome do Umbandista</span>
                  <span className="block text-[11.5px] font-extrabold text-white truncate max-w-[210px] uppercase font-sans tracking-tight">
                    {medium.name}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="block text-[7px] text-slate-400 uppercase tracking-widest font-bold">Registro Geral</span>
                    <span className="text-[10.5px] font-bold text-amber-300 font-mono">
                      nº {medium.registrationNumber || '---'}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[7px] text-slate-400 uppercase tracking-widest font-bold">Data Filiação</span>
                    <span className="text-[10px] font-semibold text-slate-200 font-mono">
                      {formattedDate}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between border-t border-slate-800/40 pt-1.5">
              <div>
                <span className="block text-[6.5px] text-slate-400 uppercase tracking-widest leading-none font-bold">Função Ritual</span>
                <span className="text-[9.5px] font-extrabold text-amber-500 uppercase tracking-tight">
                  {medium.role}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm bg-slate-900/60 p-1 rounded-md" title="Selo de Falange">{selectedSymbol}</span>
                <span className="text-[8px] font-extrabold px-1.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded uppercase">
                  ATIVO
                </span>
              </div>
            </div>
          </div>

          {/* BACK (VERSO) */}
          <div className="relative w-[340px] h-[216px] bg-slate-950 rounded-2xl overflow-hidden shadow-lg border border-slate-900/60 text-white flex flex-col justify-between p-4 shrink-0 print:shadow-none print:border-slate-300">
            {/* Ambient watermarks */}
            <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-slate-800/10 rounded-full blur-xl pointer-events-none" />
            
            {/* Rules Text / Duties */}
            <div className="space-y-1.5 text-center px-1">
              <h5 className="text-[8px] font-black text-amber-400 uppercase tracking-wider border-b border-slate-800 pb-1">
                 Deveres e Compromissos do Filiação
              </h5>
              <ol className="text-[6.5px] text-slate-400 text-left list-decimal pl-3 space-y-0.5 font-medium leading-normal">
                <li>Manter-se firme na corrente, cumprindo os cronogramas rituais com caridade e respeito.</li>
                <li>Respeitar a hierarquia da casa e a preservação dos preceitos do terreiro.</li>
                <li>Este cartão é pessoal e intransferível, válido mediante status ativo na tesouraria.</li>
                <li>A Umbanda é paz, amor, caridade e evolução sob a luz dos sagrados Orixás.</li>
              </ol>
            </div>

            {/* Barcode & Signatures area */}
            <div className="space-y-2 mt-2">
              <div className="flex justify-between items-end gap-3 px-1">
                
                {/* Simulated Barcode */}
                <div className="space-y-0.5 shrink-0 bg-white p-1 rounded-sm">
                  <div className="flex items-stretch h-5 w-20 bg-white">
                    {/* Fake barcode bars */}
                    <div className="w-1.5 bg-black" />
                    <div className="w-0.5 bg-white" />
                    <div className="w-1 bg-black" />
                    <div className="w-1 bg-white" />
                    <div className="w-0.5 bg-black" />
                    <div className="w-0.5 bg-white" />
                    <div className="w-1.5 bg-black" />
                    <div className="w-1 bg-white" />
                    <div className="w-0.5 bg-black" />
                    <div className="w-0.5 bg-white" />
                    <div className="w-1.5 bg-black" />
                    <div className="w-1 bg-white" />
                    <div className="w-1 bg-black" />
                    <div className="w-0.5 bg-white" />
                    <div className="w-0.5 bg-black" />
                    <div className="w-1.5 bg-black" />
                  </div>
                  <div className="text-[6px] text-black font-semibold text-center font-mono tracking-widest leading-none">
                    *TUPB-{medium.registrationNumber || '1001'}*
                  </div>
                </div>

                {/* Director Signature placeholder */}
                <div className="flex-1 flex flex-col items-center">
                  <div className="w-full border-b border-dashed border-slate-600 h-6 flex items-end justify-center">
                    <span className="font-serif italic text-[10px] text-amber-200/50 leading-none">Caboclo das Sete Encruzilhadas</span>
                  </div>
                  <span className="text-[5.5px] text-slate-500 uppercase tracking-widest font-bold mt-0.5">
                    Assinatura Espiritual do Dirigente
                  </span>
                </div>
              </div>

              {/* Bottom house label */}
              <div className="text-center text-[7px] text-slate-500 font-mono border-t border-slate-900 pt-1 flex justify-between items-center">
                <span>Fundada em 15/11/1908</span>
                <span>TUPB - Credencial Interna</span>
              </div>
            </div>

          </div>

        </div>

        {/* PRINT ACTIONS BAR - hidden during print */}
        <div className="flex flex-col sm:flex-row justify-end gap-3 pt-4 border-t border-slate-100 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Fechar Janela
          </button>
          
          <button
            type="button"
            onClick={() => {
              window.print();
            }}
            className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors shadow-md cursor-pointer hover:scale-[1.02]"
          >
            <Printer className="h-4 w-4" />
            Imprimir Credencial (Papel)
          </button>
        </div>

      </div>
    </div>
  );
};
