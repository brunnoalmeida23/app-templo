/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Medium, MonthlyFee, TerreiroEvent, PaymentStats, BillPayable } from './types';

// Default list of mediums with registration numbers and pre-configured passwords
const DEFAULT_MEDIUMS: Medium[] = [
  {
    id: 'm1',
    name: 'Mariana de Souza (Oxum)',
    email: 'mariana.oxum@gmail.com',
    phone: '(11) 98765-4301',
    role: 'Médium de Corrente',
    active: true,
    startDate: '2025-01-15',
    monthlyValue: 60.00,
    registrationNumber: '1001',
    password: '123'
  },
  {
    id: 'm2',
    name: 'Carlos Alberto Penha (Xangô)',
    email: 'carlos.xango@outlook.com',
    phone: '(11) 97654-3202',
    role: 'Ogã / Atabaqueiro',
    active: true,
    startDate: '2024-03-10',
    monthlyValue: 60.00,
    registrationNumber: '1002'
  },
  {
    id: 'm3',
    name: 'Juliana Santana (Iemanjá)',
    email: 'juliana.iemanja@hotmail.com',
    phone: '(21) 99888-2233',
    role: 'Dirigente Espiritual',
    active: true,
    startDate: '2022-08-20',
    monthlyValue: 80.00,
    registrationNumber: '1003',
    password: '123'
  },
  {
    id: 'm4',
    name: 'Roberto Dias (Preto Velho)',
    email: 'roberto.dias@gmail.com',
    phone: '(11) 98123-4567',
    role: 'Cambone',
    active: true,
    startDate: '2025-05-02',
    monthlyValue: 50.00,
    registrationNumber: '1004'
  },
  {
    id: 'm5',
    name: 'Ana Carolina Lima (Iansã)',
    email: 'ana.iansa@yahoo.com.br',
    phone: '(31) 99777-1122',
    role: 'Médium Iniciante',
    active: true,
    startDate: '2026-02-10',
    monthlyValue: 50.00,
    registrationNumber: '1005'
  },
  {
    id: 'm6',
    name: 'Lucas Ferreira (Ogum)',
    email: 'lucas.ogum@gmail.com',
    phone: '(11) 96321-4587',
    role: 'Médium de Corrente',
    active: false, // Inactive example
    startDate: '2023-11-01',
    monthlyValue: 60.00,
    registrationNumber: '1006'
  }
];

// Default list of monthly fees
const DEFAULT_FEES: MonthlyFee[] = [
  // April 2026 (All paid)
  {
    id: 'f1_m1',
    mediumId: 'm1',
    mediumName: 'Mariana de Souza (Oxum)',
    referenceMonth: '2026-04',
    dueDate: '2026-04-10',
    value: 60.00,
    status: 'paid',
    paymentDate: '2026-04-08',
    paymentMethod: 'pix',
    pixCode: '00020101021126360014br.gov.bcb.pix0114templo@pix.org520400005303986540560.005802BR5915TerreiroUmbanda6009Sao_Paulo62070503***6304ABCD',
    notes: 'Pago adiantado pelo aplicativo'
  },
  {
    id: 'f1_m2',
    mediumId: 'm2',
    mediumName: 'Carlos Alberto Penha (Xangô)',
    referenceMonth: '2026-04',
    dueDate: '2026-04-10',
    value: 60.00,
    status: 'paid',
    paymentDate: '2026-04-10',
    paymentMethod: 'dinheiro',
    notes: 'Pago em mãos ao tesoureiro'
  },
  {
    id: 'f1_m3',
    mediumId: 'm3',
    mediumName: 'Juliana Santana (Iemanjá)',
    referenceMonth: '2026-04',
    dueDate: '2026-04-10',
    value: 80.00,
    status: 'paid',
    paymentDate: '2026-04-09',
    paymentMethod: 'pix'
  },
  {
    id: 'f1_m4',
    mediumId: 'm4',
    mediumName: 'Roberto Dias (Preto Velho)',
    referenceMonth: '2026-04',
    dueDate: '2026-04-10',
    value: 50.00,
    status: 'paid',
    paymentDate: '2026-04-10',
    paymentMethod: 'pix'
  },
  {
    id: 'f1_m5',
    mediumId: 'm5',
    mediumName: 'Ana Carolina Lima (Iansã)',
    referenceMonth: '2026-04',
    dueDate: '2026-04-10',
    value: 50.00,
    status: 'paid',
    paymentDate: '2026-04-11',
    paymentMethod: 'boleto'
  },

  // May 2026 (Mixed statuses: paid, pending/overdue since due date was 2026-05-10 and current time is 2026-06-01)
  {
    id: 'f2_m1',
    mediumId: 'm1',
    mediumName: 'Mariana de Souza (Oxum)',
    referenceMonth: '2026-05',
    dueDate: '2026-05-10',
    value: 60.00,
    status: 'paid',
    paymentDate: '2026-05-09',
    paymentMethod: 'pix'
  },
  {
    id: 'f2_m2',
    mediumId: 'm2',
    mediumName: 'Carlos Alberto Penha (Xangô)',
    referenceMonth: '2026-05',
    dueDate: '2026-05-10',
    value: 60.00,
    status: 'overdue', // past due date of May 10, time is June 1
    paymentDate: null,
    paymentMethod: null
  },
  {
    id: 'f2_m3',
    mediumId: 'm3',
    mediumName: 'Juliana Santana (Iemanjá)',
    referenceMonth: '2026-05',
    dueDate: '2026-05-10',
    value: 80.00,
    status: 'paid',
    paymentDate: '2026-05-10',
    paymentMethod: 'pix'
  },
  {
    id: 'f2_m4',
    mediumId: 'm4',
    mediumName: 'Roberto Dias (Preto Velho)',
    referenceMonth: '2026-05',
    dueDate: '2026-05-10',
    value: 50.00,
    status: 'overdue', // overdue
    paymentDate: null,
    paymentMethod: null,
    comprovanteUploaded: true, // Simulation: medium uploaded comprovante, waiting for admin approval
    comprovanteFileName: 'comprovante_maio_roberto.pdf'
  },
  {
    id: 'f2_m5',
    mediumId: 'm5',
    mediumName: 'Ana Carolina Lima (Iansã)',
    referenceMonth: '2026-05',
    dueDate: '2026-05-10',
    value: 50.00,
    status: 'paid',
    paymentDate: '2026-05-05',
    paymentMethod: 'pix'
  },

  // June 2026 (Issued mensalities, current date is June 1st, so they are 'pending' till June 10)
  {
    id: 'f3_m1',
    mediumId: 'm1',
    mediumName: 'Mariana de Souza (Oxum)',
    referenceMonth: '2026-06',
    dueDate: '2026-06-10',
    value: 60.00,
    status: 'pending',
    paymentDate: null,
    paymentMethod: null
  },
  {
    id: 'f3_m2',
    mediumId: 'm2',
    mediumName: 'Carlos Alberto Penha (Xangô)',
    referenceMonth: '2026-06',
    dueDate: '2026-06-10',
    value: 60.00,
    status: 'pending',
    paymentDate: null,
    paymentMethod: null
  },
  {
    id: 'f3_m3',
    mediumId: 'm3',
    mediumName: 'Juliana Santana (Iemanjá)',
    referenceMonth: '2026-06',
    dueDate: '2026-06-10',
    value: 80.00,
    status: 'pending',
    paymentDate: null,
    paymentMethod: null
  },
  {
    id: 'f3_m4',
    mediumId: 'm4',
    mediumName: 'Roberto Dias (Preto Velho)',
    referenceMonth: '2026-06',
    dueDate: '2026-06-10',
    value: 50.00,
    status: 'pending',
    paymentDate: null,
    paymentMethod: null
  },
  {
    id: 'f3_m5',
    mediumId: 'm5',
    mediumName: 'Ana Carolina Lima (Iansã)',
    referenceMonth: '2026-06',
    dueDate: '2026-06-10',
    value: 50.00,
    status: 'pending',
    paymentDate: null,
    paymentMethod: null
  }
];

// Helper to load/save from localStorage
export const loadMediumsFromStorage = (): Medium[] => {
  if (typeof window === 'undefined') return DEFAULT_MEDIUMS;
  const stored = localStorage.getItem('terreiro_mediums');
  if (stored) {
    try {
      const parsed = JSON.parse(stored) as Medium[];
      let changed = false;
      const migrated = parsed.map((m, idx) => {
        const defaultMatch = DEFAULT_MEDIUMS.find(dm => dm.id === m.id);
        const updated = { ...m };
        if (!updated.registrationNumber) {
          updated.registrationNumber = defaultMatch?.registrationNumber || String(1001 + idx);
          changed = true;
        }
        if (defaultMatch?.password && !updated.password) {
          updated.password = defaultMatch.password;
          changed = true;
        }
        return updated;
      });
      if (changed) {
        localStorage.setItem('terreiro_mediums', JSON.stringify(migrated));
      }
      return migrated;
    } catch (e) {
      console.error("Error reading localStorage mediums:", e);
    }
  }
  // Initialize with default
  localStorage.setItem('terreiro_mediums', JSON.stringify(DEFAULT_MEDIUMS));
  return DEFAULT_MEDIUMS;
};

export const saveMediumsToStorage = (mediums: Medium[]): void => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('terreiro_mediums', JSON.stringify(mediums));
  }
};

export const loadFeesFromStorage = (): MonthlyFee[] => {
  if (typeof window === 'undefined') return DEFAULT_FEES;
  const stored = localStorage.getItem('terreiro_fees');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      console.error("Error reading localStorage fees:", e);
    }
  }
  // Initialize with default
  localStorage.setItem('terreiro_fees', JSON.stringify(DEFAULT_FEES));
  return DEFAULT_FEES;
};

export const saveFeesToStorage = (fees: MonthlyFee[]): void => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('terreiro_fees', JSON.stringify(fees));
  }
};

// Calculate financial statistics
export const getStats = (fees: MonthlyFee[]): PaymentStats => {
  let totalCollected = 0;
  let totalPending = 0;
  let totalOverdue = 0;
  let paidCount = 0;
  let pendingCount = 0;
  let overdueCount = 0;

  fees.forEach(fee => {
    if (fee.status === 'paid') {
      totalCollected += fee.value;
      paidCount++;
    } else if (fee.status === 'pending') {
      totalPending += fee.value;
      pendingCount++;
    } else if (fee.status === 'overdue') {
      totalOverdue += fee.value;
      overdueCount++;
    }
  });

  return {
    totalCollected,
    totalPending,
    totalOverdue,
    paidCount,
    pendingCount,
    overdueCount
  };
};

// Generate realistic PIX EMV BR Code
export const getPixEMVCode = (name: string, month: string, amount: number): string => {
  // Format info nicely in uppercase string
  const cleanName = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9 ]/g, "").slice(0, 15).toUpperCase();
  const cleanMonth = month.replace('-', '');
  const cleanAmount = amount.toFixed(2);
  
  // Build a realistic BrCode string format
  return `00020101021226580014br.gov.bcb.pix0114templo@pix.org0230Mensalidade-${cleanMonth}-${cleanName}520400005303986540${cleanAmount.length.toString().padStart(2, '0')}${cleanAmount}5802BR5915TemploMensal6009Sao_Paulo62070503***6304F2E4`;
};

// Helper for portuguese months
export const getPortgueseMonthName = (yearMonth: string): string => {
  const [year, month] = yearMonth.split('-');
  const months: { [key: string]: string } = {
    '01': 'Janeiro',
    '02': 'Fevereiro',
    '03': 'Março',
    '04': 'Abril',
    '05': 'Maio',
    '06': 'Junho',
    '07': 'Julho',
    '08': 'Agosto',
    '09': 'Setembro',
    '10': 'Outubro',
    '11': 'Novembro',
    '12': 'Dezembro'
  };
  return `${months[month]} de ${year}`;
};

export const getPortugueseRoleDescription = (role: string): string => {
  return role;
};

// Default list of sporadic events
const DEFAULT_EVENTS: TerreiroEvent[] = [
  {
    id: 'e1',
    name: 'Festa de Cosme e Damião',
    date: '2026-09-27',
    description: 'Arrecadação de fundos para compra de doces, brinquedos e bolo para a festividade das Crianças.',
    costPerMedium: 30.00,
    billingIssued: true
  },
  {
    id: 'e2',
    name: 'Reforma do Telhado do Gongá',
    date: '2026-07-15',
    description: 'Manutenção estrutural do telhado do terreiro antes do início do período de chuvas.',
    costPerMedium: 50.00,
    billingIssued: false
  }
];

export const loadEventsFromStorage = (): TerreiroEvent[] => {
  if (typeof window === 'undefined') return DEFAULT_EVENTS;
  const stored = localStorage.getItem('terreiro_events');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      console.error("Error reading localStorage events:", e);
    }
  }
  localStorage.setItem('terreiro_events', JSON.stringify(DEFAULT_EVENTS));
  return DEFAULT_EVENTS;
};

export const saveEventsToStorage = (events: TerreiroEvent[]): void => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('terreiro_events', JSON.stringify(events));
  }
};

// Default bills payable data (demonstration expense flow)
const DEFAULT_BILLS: BillPayable[] = [
  {
    id: 'b1',
    description: 'Energia Elétrica - Enel (Maio/2026)',
    dueDate: '2026-05-15',
    value: 124.50,
    status: 'paid',
    paymentDate: '2026-05-14',
    category: 'energia',
    notes: 'Débito automático efetuado.'
  },
  {
    id: 'b2',
    description: 'Taxa de Água Sabesp (Maio/2026)',
    dueDate: '2026-05-20',
    value: 68.90,
    status: 'paid',
    paymentDate: '2026-05-18',
    category: 'agua',
    notes: 'Pago via PIX.'
  },
  {
    id: 'b3',
    description: 'Compra de Velas Brancas e Incensos de Arruda',
    dueDate: '2026-06-05',
    value: 150.00,
    status: 'pending',
    paymentDate: null,
    category: 'artigos',
    notes: 'Distribuidora Sete Flechas.'
  },
  {
    id: 'b4',
    description: 'Produtos de Limpeza (Cloro, Sabão, Desinfetante)',
    dueDate: '2026-06-08',
    value: 85.30,
    status: 'pending',
    paymentDate: null,
    category: 'limpeza',
    notes: 'Supermercado local.'
  },
  {
    id: 'b5',
    description: 'Manutenção do Telhado do Gongá (Sinal do Pedreiro)',
    dueDate: '2026-06-12',
    value: 200.00,
    status: 'pending',
    paymentDate: null,
    category: 'reforma',
    notes: 'Referente ao conserto de infiltrações.'
  }
];

export const loadBillsFromStorage = (): BillPayable[] => {
  if (typeof window === 'undefined') return DEFAULT_BILLS;
  const stored = localStorage.getItem('terreiro_bills');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      console.error("Error reading localStorage bills:", e);
    }
  }
  localStorage.setItem('terreiro_bills', JSON.stringify(DEFAULT_BILLS));
  return DEFAULT_BILLS;
};

export const saveBillsToStorage = (bills: BillPayable[]): void => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('terreiro_bills', JSON.stringify(bills));
  }
};


