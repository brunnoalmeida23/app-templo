/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Medium, MonthlyFee } from '../types';
import { getPortgueseMonthName } from '../data';

interface EmailNotificationOptions {
  medium: Medium;
  fee: MonthlyFee;
  type: 'issued' | 'payment_confirmed';
}

/**
 * Simulates sending an email notification to a medium.
 * In a real-world application, this would integrate with a service like SendGrid, AWS SES, or a custom backend endpoint.
 */
export const sendEmailNotification = async ({ medium, fee, type }: EmailNotificationOptions): Promise<boolean> => {
  return new Promise((resolve) => {
    console.log(`[Notification Service] Preparing to send email to: ${medium.name} (${medium.email || 'No email provided'})`);
    
    setTimeout(() => {
      if (!medium.email) {
        console.warn(`[Notification Service] Could not send email: Medium ${medium.name} has no email address configured.`);
        resolve(false);
        return;
      }

      const monthName = getPortgueseMonthName(fee.referenceMonth);

      if (type === 'issued') {
        console.log(`
          ================= MOCK EMAIL SENT =================
          To: ${medium.email}
          Subject: Nova Mensalidade Gerada - ${monthName}
          
          Olá, ${medium.name},
          
          Informamos que a mensalidade referente a ${monthName} no valor de R$ ${fee.value.toFixed(2)} foi gerada e já está disponível para pagamento.
          
          Por favor, acesse o sistema do terreiro para obter os dados do PIX e anexar o seu comprovante.
          
          Atenciosamente,
          Administração do Terreiro
          ===================================================
        `);
      } else if (type === 'payment_confirmed') {
        console.log(`
          ================= MOCK EMAIL SENT =================
          To: ${medium.email}
          Subject: Pagamento Confirmado - Mensalidade de ${monthName}
          
          Olá, ${medium.name},
          
          O pagamento da sua mensalidade referente a ${monthName} no valor de R$ ${fee.value.toFixed(2)} foi confirmado pela administração com sucesso!
          
          Agradecemos a sua contribuição.
          
          Atenciosamente,
          Administração do Terreiro
          ===================================================
        `);
      }
      
      resolve(true);
    }, 1000); // Simulate network delay
  });
};
