/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type FeeStatus = 'paid' | 'pending' | 'overdue';

export interface Medium {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  active: boolean;
  startDate: string;
  monthlyValue: number;
  registrationNumber?: string; // Optional or auto-generated: e.g. "1001", "1002"
  password?: string;           // Password set by the medium
}

export interface MonthlyFee {
  id: string;
  mediumId: string;
  mediumName: string;
  referenceMonth: string; // Format: "YYYY-MM"
  dueDate: string;        // Format: "YYYY-MM-DD"
  value: number;
  status: FeeStatus;
  paymentDate: string | null;  // Format: "YYYY-MM-DD"
  paymentMethod: 'pix' | 'dinheiro' | 'boleto' | null;
  pixCode?: string;
  comprovanteUploaded?: boolean;
  comprovanteFileName?: string;
  notes?: string;
  isEventFee?: boolean;        // If this fee stems from a sporadic event
  eventName?: string;          // Name of the corresponding event
}

export interface TerreiroEvent {
  id: string;
  name: string;
  date: string;                // Format: "YYYY-MM-DD"
  description: string;
  costPerMedium: number;
  billingIssued: boolean;      // Marks if fees were already dispatched to active mediums
}

export interface PaymentStats {
  totalCollected: number;
  totalPending: number;
  totalOverdue: number;
  paidCount: number;
  pendingCount: number;
  overdueCount: number;
}

export interface BillPayable {
  id: string;
  description: string;
  dueDate: string;        // Format: "YYYY-MM-DD"
  value: number;
  status: 'paid' | 'pending';
  paymentDate: string | null; // Format: "YYYY-MM-DD"
  category: 'energia' | 'agua' | 'artigos' | 'reforma' | 'limpeza' | 'outros';
  notes?: string;
}

